# Shooter
1. Subí esta carpeta a un repo de GitHub (rama main).
2. Actions compila solo y crea un Release "latest-build" con app-debug.apk y gamedata.zip.
3. Instalá el APK: al abrirlo descarga gamedata.zip (carpeta gamedata/) y habilita JUGAR.
Para cambiar el juego, editá gamedata/config.json y hacé push.
