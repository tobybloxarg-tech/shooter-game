# Shooter
1. Subí esta carpeta a un repo de GitHub (rama main).
2. Actions compila solo y crea un Release "latest-build" con app-debug.apk y gamedata.zip.
3. Instalá el APK: al abrirlo descarga gamedata.zip (carpeta gamedata/) y habilita JUGAR.
Para cambiar el juego, editá gamedata/config.json y hacé push.

## Wi-Fi co-op status (experimental)

The `prototype-wifi-coop` branch contains a debug-only LAN co-op experiment. It is not a production release and is not yet integrated with the complete solo `GameView` rules, progression/upgrades, or abilities. The current multiplayer runtime is a separate, smaller simulation; do not represent it as feature-equivalent to solo play. Networked play and disconnect behavior still require testing on multiple physical Android devices on the same Wi-Fi. The password is sent over the local network without encryption. Do not reuse an important password. The prototype branch workflow builds debug APKs only and does not publish a production release.
