package com.zapia.shooter

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class StoreActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var coinsView: TextView
    private lateinit var mode: String

    class Up(val key: String, val name: String, val base: Int, val max: Int, val desc: String)
    private val ups = listOf(
        Up("fire", "Cadencia", 50, 5, "Dispara más rápido"),
        Up("dmg", "Daño", 80, 4, "Cada bala hace más daño"),
        Up("life", "Vidas extra", 100, 3, "+1 vida al empezar")
    )
    private val skinNames = listOf("Cian", "Verde", "Naranja", "Rosa", "Dorado")
    private val skinPrices = listOf(0, 100, 200, 400, 800)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        mode = intent.getStringExtra("mode") ?: "upgrades"
        val root = Ui.root(this)
        Ui.add(root, Ui.title(this, if (mode == "shop") "TIENDA" else "MEJORAS"))
        coinsView = Ui.text(this, ""); Ui.add(root, coinsView)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.add(root, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(root)
    }
    override fun onResume() { super.onResume(); Audio.start(this); refresh() }
    override fun onPause() { super.onPause(); Audio.stopSoon() }

    private fun refresh() {
        coinsView.text = "Monedas: ${Save.coins(this)}"
        list.removeAllViews()
        if (mode == "upgrades") for (u in ups) {
            val lv = Save.lvl(this, u.key)
            val cost = u.base * (lv + 1)
            val label = if (lv >= u.max) "${u.name}  (MAX)\n${u.desc}" else "${u.name}  nivel $lv/${u.max}\n${u.desc}  —  $cost monedas"
            Ui.add(list, Ui.button(this, label) {
                if (lv < u.max && Save.coins(this) >= cost) {
                    Save.addCoins(this, -cost); Save.setLvl(this, u.key, lv + 1); refresh()
                }
            }.also { it.isEnabled = lv < u.max && Save.coins(this) >= cost })
        } else for (i in skinNames.indices) {
            val owned = Save.owned(this, i)
            val sel = Save.skin(this) == i
            val label = when { sel -> "Nave ${skinNames[i]}  ✔ en uso"; owned -> "Nave ${skinNames[i]}  (usar)"; else -> "Nave ${skinNames[i]}  —  ${skinPrices[i]} monedas" }
            Ui.add(list, Ui.button(this, label, Skins.color(i)) {
                if (owned) Save.setSkin(this, i)
                else if (Save.coins(this) >= skinPrices[i]) { Save.addCoins(this, -skinPrices[i]); Save.setOwned(this, i); Save.setSkin(this, i) }
                refresh()
            }.also { it.setTextColor(Color.BLACK) })
        }
    }
}

object Skins {
    fun color(i: Int) = intArrayOf(Color.CYAN, Color.GREEN, Color.rgb(255, 150, 0), Color.rgb(255, 105, 180), Color.rgb(255, 215, 0))[i.coerceIn(0, 4)]
}
