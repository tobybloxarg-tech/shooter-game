package com.zapia.shooter

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.Button

class OptionsActivity : Activity() {
    private lateinit var m: Button
    private lateinit var f: Button
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = Ui.root(this)
        Ui.add(l, Ui.title(this, "OPCIONES"))
        m = Ui.button(this, "") { Save.setMusic(this, !Save.music(this)); Audio.start(this); upd() }
        f = Ui.button(this, "") { Save.setSfx(this, !Save.sfx(this)); upd() }
        Ui.add(l, m); Ui.add(l, f)
        Ui.add(l, Ui.button(this, "BORRAR PROGRESO", Color.rgb(160, 40, 40)) { Save.reset(this); upd() })
        Ui.add(l, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(l); upd()
    }
    private fun upd() {
        m.text = "Música: " + if (Save.music(this)) "SÍ" else "NO"
        f.text = "Efectos de sonido: " + if (Save.sfx(this)) "SÍ" else "NO"
    }
    override fun onResume() { super.onResume(); Audio.start(this) }
    override fun onPause() { super.onPause(); Audio.stopSoon() }
}
