package com.zapia.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

// Se reemplaza automáticamente en GitHub Actions por tu usuario/repo
const val DATA_URL = "https://github.com/REPO_PLACEHOLDER/releases/download/latest-build/gamedata.zip"

class LauncherActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var btn: Button

    fun dataDir() = File(getExternalFilesDir(null), "gamedata")
    fun installed() = File(dataDir(), "config.json").exists() && File(dataDir(), "explosion.wav").exists()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(15, 15, 30)); setPadding(60, 60, 60, 60)
        }
        val title = TextView(this).apply { text = "SHOOTER"; textSize = 36f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        status = TextView(this).apply { setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 40, 0, 20) }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = ProgressBar.GONE }
        btn = Button(this).apply { setOnClickListener { onButton() } }
        listOf(title, status, bar, btn).forEach { l.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        setContentView(l)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        if (installed()) { status.text = "Archivos del juego listos"; btn.text = "JUGAR" }
        else { status.text = "Faltan los archivos del juego.\nHay que descargarlos (una sola vez)."; btn.text = "DESCARGAR ARCHIVOS" }
    }

    private fun onButton() {
        if (installed()) startActivity(Intent(this, MenuActivity::class.java)) else download()
    }

    private fun download() {
        btn.isEnabled = false; bar.visibility = ProgressBar.VISIBLE
        Thread {
            try {
                val tmp = File(cacheDir, "gamedata.zip")
                val c = URL(DATA_URL).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = true; c.connect()
                val total = c.contentLength.toLong()
                c.inputStream.use { i -> tmp.outputStream().use { o ->
                    val buf = ByteArray(8192); var done = 0L; var n: Int
                    while (i.read(buf).also { n = it } > 0) {
                        o.write(buf, 0, n); done += n
                        if (total > 0) runOnUiThread { bar.progress = (done * 100 / total).toInt(); status.text = "Descargando… ${bar.progress}%" }
                    }
                } }
                runOnUiThread { status.text = "Instalando archivos…" }
                val dest = dataDir().apply { deleteRecursively(); mkdirs() }
                ZipInputStream(tmp.inputStream()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val f = File(dest, e.name)
                        if (!f.canonicalPath.startsWith(dest.canonicalPath)) throw SecurityException("zip inválido")
                        if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { z.copyTo(it) } }
                        e = z.nextEntry
                    }
                }
                tmp.delete()
                runOnUiThread { bar.visibility = ProgressBar.GONE; btn.isEnabled = true; refresh() }
            } catch (ex: Exception) {
                runOnUiThread { bar.visibility = ProgressBar.GONE; btn.isEnabled = true; status.text = "Error: ${ex.message}\nReintentá."; btn.text = "REINTENTAR" }
            }
        }.start()
    }
}
