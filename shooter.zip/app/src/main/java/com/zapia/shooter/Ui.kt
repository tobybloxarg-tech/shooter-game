package com.zapia.shooter

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*

object Ui {
    fun root(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        setBackgroundColor(Color.rgb(15, 15, 30)); setPadding(60, 60, 60, 60)
    }
    fun title(c: Context, t: String, size: Float = 34f) = TextView(c).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 0, 0, 30)
    }
    fun text(c: Context, t: String) = TextView(c).apply {
        text = t; textSize = 18f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 10, 0, 10)
    }
    fun button(c: Context, t: String, color: Int = Color.rgb(40, 90, 200), onClick: () -> Unit) = Button(c).apply {
        text = t; setTextColor(Color.WHITE); textSize = 18f
        background = GradientDrawable().apply { setColor(color); cornerRadius = 30f }
        setOnClickListener { onClick() }
    }
    fun add(l: LinearLayout, v: android.view.View) {
        l.addView(v, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 12, 0, 12) })
    }
}
