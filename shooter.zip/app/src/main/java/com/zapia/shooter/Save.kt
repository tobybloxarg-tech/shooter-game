package com.zapia.shooter

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.io.File

object Save {
    private fun p(c: Context) = c.getSharedPreferences("save", Context.MODE_PRIVATE)
    fun coins(c: Context) = p(c).getInt("coins", 0)
    fun addCoins(c: Context, n: Int) = p(c).edit().putInt("coins", coins(c) + n).apply()
    fun lvl(c: Context, k: String) = p(c).getInt("lvl_$k", 0)
    fun setLvl(c: Context, k: String, v: Int) = p(c).edit().putInt("lvl_$k", v).apply()
    fun music(c: Context) = p(c).getBoolean("music", true)
    fun sfx(c: Context) = p(c).getBoolean("sfx", true)
    fun setMusic(c: Context, v: Boolean) = p(c).edit().putBoolean("music", v).apply()
    fun setSfx(c: Context, v: Boolean) = p(c).edit().putBoolean("sfx", v).apply()
    fun skin(c: Context) = p(c).getInt("skin", 0)
    fun setSkin(c: Context, v: Int) = p(c).edit().putInt("skin", v).apply()
    fun owned(c: Context, i: Int) = i == 0 || p(c).getBoolean("skin_$i", false)
    fun setOwned(c: Context, i: Int) = p(c).edit().putBoolean("skin_$i", true).apply()
    fun best(c: Context) = p(c).getInt("best", 0)
    fun setBest(c: Context, v: Int) = p(c).edit().putInt("best", v).apply()
    fun reset(c: Context) = p(c).edit().clear().apply()
    fun dataDir(c: Context) = File(c.getExternalFilesDir(null), "gamedata")
}

object Audio {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopNow() }

    fun start(c: Context) {
        h.removeCallbacks(stopper)
        if (!Save.music(c)) { stopNow(); return }
        if (mp?.isPlaying == true) return
        val f = File(Save.dataDir(c), "music_menu.wav")
        if (!f.exists()) return
        stopNow()
        mp = MediaPlayer().apply { setDataSource(f.path); isLooping = true; setVolume(0.6f, 0.6f); prepare(); start() }
    }
    fun stopSoon() { h.removeCallbacks(stopper); h.postDelayed(stopper, 400) }
    fun stopNow() { h.removeCallbacks(stopper); mp?.release(); mp = null }
}
