package com.zapia.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.os.Handler
import android.os.Looper

class MenuActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var rb: Button
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { updRoulette(); h.postDelayed(this, 1000) } }
    private fun updRoulette() {
        val left = (Save.NEED_MS - Save.playMs(this@MenuActivity)) / 1000
        rb.text = when {
            Save.pending(this) >= 0 -> "RULETA 🎁 ¡Premio para reclamar!"
            left <= 0 -> "RULETA ¡LISTA PARA GIRAR!"
            else -> "RULETA  🔒 %02d:%02d".format(left / 60, left % 60)
        }
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = Ui.root(this)
        Ui.add(l, Ui.title(this, "SHOOTER", 42f))
        info = Ui.text(this, ""); Ui.add(l, info)
        Ui.add(l, Ui.button(this, "▶  PLAY", Color.rgb(30, 160, 80)) { startActivity(Intent(this, GameActivity::class.java)) })
        Ui.add(l, Ui.button(this, "MEJORAS") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "upgrades")) })
        Ui.add(l, Ui.button(this, "TIENDA") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "shop")) })
        rb = Ui.button(this, "RULETA", Color.rgb(160, 90, 200)) { startActivity(Intent(this, RouletteActivity::class.java)) }
        Ui.add(l, rb)
        Ui.add(l, Ui.button(this, "OPCIONES", Color.rgb(90, 90, 110)) { startActivity(Intent(this, OptionsActivity::class.java)) })
        setContentView(l)
    }
    override fun onResume() {
        super.onResume(); Audio.start(this); h.post(tick)
        info.text = "Monedas: ${Save.coins(this)}   |   Récord: ${Save.best(this)}"
    }
    override fun onPause() { super.onPause(); Audio.stopSoon(); h.removeCallbacks(tick) }
}
