package com.zapia.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView

class MenuActivity : Activity() {
    private lateinit var info: TextView
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = Ui.root(this)
        Ui.add(l, Ui.title(this, "SHOOTER", 42f))
        info = Ui.text(this, ""); Ui.add(l, info)
        Ui.add(l, Ui.button(this, "▶  PLAY", Color.rgb(30, 160, 80)) { startActivity(Intent(this, GameActivity::class.java)) })
        Ui.add(l, Ui.button(this, "MEJORAS") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "upgrades")) })
        Ui.add(l, Ui.button(this, "TIENDA") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "shop")) })
        Ui.add(l, Ui.button(this, "OPCIONES", Color.rgb(90, 90, 110)) { startActivity(Intent(this, OptionsActivity::class.java)) })
        setContentView(l)
    }
    override fun onResume() {
        super.onResume(); Audio.start(this)
        info.text = "Monedas: ${Save.coins(this)}   |   Récord: ${Save.best(this)}"
    }
    override fun onPause() { super.onPause(); Audio.stopSoon() }
}
