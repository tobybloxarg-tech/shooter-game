package com.zapia.shooter

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.SurfaceView
import org.json.JSONObject
import kotlin.random.Random

class GameView(ctx: Context, cfg: String) : SurfaceView(ctx), Runnable {
    private val j = JSONObject(cfg)
    private val enemySpeed = j.optDouble("enemySpeed", 6.0).toFloat()
    private val spawnMs = j.optLong("spawnMs", 700)
    private val fireMs = j.optLong("fireMs", 220)
    private val lives0 = j.optInt("lives", 3)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var thread: Thread? = null
    @Volatile private var running = false

    class B(var x: Float, var y: Float)
    private val bullets = ArrayList<B>(); private val enemies = ArrayList<B>()
    private var px = 0f; private var score = 0; private var lives = lives0
    private var lastShot = 0L; private var lastSpawn = 0L

    fun start() { running = true; thread = Thread(this).also { it.start() } }
    fun stop() { running = false; thread?.join() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        px = e.x
        if (e.action == MotionEvent.ACTION_DOWN && lives <= 0) { lives = lives0; score = 0; bullets.clear(); enemies.clear() }
        return true
    }

    override fun run() {
        while (running) {
            val h = holder
            if (!h.surface.isValid) continue
            val c = h.lockCanvas() ?: continue
            try { update(c.width, c.height); draw(c) } finally { h.unlockCanvasAndPost(c) }
            Thread.sleep(16)
        }
    }

    private fun update(w: Int, hh: Int) {
        if (px == 0f) px = w / 2f
        if (lives <= 0) return
        val now = System.currentTimeMillis()
        if (now - lastShot > fireMs) { bullets.add(B(px, hh - 160f)); lastShot = now }
        if (now - lastSpawn > spawnMs) { enemies.add(B(Random.nextFloat() * (w - 80) + 40, -40f)); lastSpawn = now }
        bullets.forEach { it.y -= 22 }; bullets.removeAll { it.y < 0 }
        enemies.forEach { it.y += enemySpeed }
        val it = enemies.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val hit = bullets.firstOrNull { Math.abs(it.x - e.x) < 40 && Math.abs(it.y - e.y) < 40 }
            if (hit != null) { bullets.remove(hit); it.remove(); score++ }
            else if (e.y > hh) { it.remove(); lives-- }
        }
    }

    private fun draw(c: Canvas) {
        c.drawColor(Color.rgb(10, 10, 25))
        p.color = Color.CYAN; c.drawRect(px - 40, c.height - 140f, px + 40, c.height - 80f, p)
        p.color = Color.YELLOW; bullets.forEach { c.drawCircle(it.x, it.y, 8f, p) }
        p.color = Color.RED; enemies.forEach { c.drawRect(it.x - 35, it.y - 35, it.x + 35, it.y + 35, p) }
        p.color = Color.WHITE; p.textSize = 56f
        c.drawText("Puntos: $score   Vidas: $lives", 30f, 90f, p)
        if (lives <= 0) c.drawText("GAME OVER - tocá para reiniciar", 40f, c.height / 2f, p)
    }
}
