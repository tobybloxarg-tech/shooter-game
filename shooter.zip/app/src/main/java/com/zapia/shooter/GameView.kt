package com.zapia.shooter

import android.content.Context
import android.graphics.*
import android.media.AudioAttributes
import android.media.SoundPool
import android.view.MotionEvent
import android.view.SurfaceView
import org.json.JSONObject
import java.io.File
import kotlin.random.Random

class GameView(private val ctx: Context, cfg: String) : SurfaceView(ctx), Runnable {
    private val j = JSONObject(cfg)
    private val enemySpeed = j.optDouble("enemySpeed", 6.0).toFloat()
    private val spawnMs = j.optLong("spawnMs", 700)
    private val wp = Weapons.list[Save.weapon(ctx).coerceIn(0, Weapons.list.size - 1)]
    private val wIdx = Save.weapon(ctx)
    private val fireMs = ((j.optLong("fireMs", 260) - 28L * Save.lvl(ctx, "fire")) * wp.rate).toLong().coerceAtLeast(55)
    private val lives0 = j.optInt("lives", 3) + Save.lvl(ctx, "life")
    private val damage = 1 + Save.lvl(ctx, "dmg") + wp.dmg
    private val shipColor = Skins.color(Save.skin(ctx))
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var thread: Thread? = null
    @Volatile private var running = false

    class B(var x: Float, var y: Float, var vx: Float = 0f, var vy: Float = -22f)
    class E(var x: Float, var y: Float, var hp: Int)
    class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Int, val color: Int)
    private val bullets = ArrayList<B>(); private val enemies = ArrayList<E>(); private val parts = ArrayList<Part>()
    private var px = 0f; private var score = 0; private var lives = lives0; private var banked = 0
    private var lastShot = 0L; private var lastSpawn = 0L
    private fun level() = 1 + score / 10
    private fun curSpeed() = (enemySpeed + 0.45f * (level() - 1)).coerceAtMost(enemySpeed * 3.2f)
    private fun curSpawn() = (spawnMs - 35L * (level() - 1)).coerceAtLeast(230L)
    private fun curHp() = 2 + (level() - 1) / 3
    private var flash = 0
    private var lastLevel = 1

    private val pool = SoundPool.Builder().setMaxStreams(6)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private var sShoot = 0; private var sBoom = 0
    private val sfxOn = Save.sfx(ctx)

    init {
        val d = Save.dataDir(ctx)
        File(d, "shoot.wav").takeIf { it.exists() }?.let { sShoot = pool.load(it.path, 1) }
        File(d, "explosion.wav").takeIf { it.exists() }?.let { sBoom = pool.load(it.path, 1) }
    }
    private fun play(id: Int, vol: Float) { if (sfxOn && id != 0) pool.play(id, vol, vol, 1, 0, 1f) }

    fun start() { running = true; thread = Thread(this).also { it.start() } }
    fun stop() { running = false; thread?.join(); bank() }
    fun release() { pool.release() }

    private fun bank() {
        val gain = score - banked
        if (gain > 0) { Save.addCoins(ctx, gain); banked = score }
        if (score > Save.best(ctx)) Save.setBest(ctx, score)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        px = e.x
        if (e.action == MotionEvent.ACTION_DOWN && lives <= 0) {
            lives = lives0; score = 0; banked = 0; lastLevel = 1; flash = 0; bullets.clear(); enemies.clear(); parts.clear()
        }
        return true
    }

    override fun run() {
        while (running) {
            val h = holder
            if (!h.surface.isValid) continue
            val c = h.lockCanvas() ?: continue
            try { update(c.width, c.height); render(c) } finally { h.unlockCanvasAndPost(c) }
            Thread.sleep(16)
        }
    }

    private fun fireWeapon(hh: Int) {
        val y = hh - 160f
        when (wIdx) {
            1 -> { bullets.add(B(px - 22, y)); bullets.add(B(px + 22, y)) }
            3 -> { bullets.add(B(px, y)); bullets.add(B(px, y, -4f, -21f)); bullets.add(B(px, y, 4f, -21f)) }
            4 -> { bullets.add(B(px - 14, y, 0f, -32f)); bullets.add(B(px + 14, y, 0f, -32f)) }
            else -> bullets.add(B(px, y))
        }
    }

    private fun explode(x: Float, y: Float) {
        val cols = intArrayOf(Color.YELLOW, Color.rgb(255, 140, 0), Color.RED, Color.WHITE)
        repeat(26) {
            val a = Random.nextFloat() * 6.283f; val sp = 3f + Random.nextFloat() * 11f
            parts.add(Part(x, y, Math.cos(a.toDouble()).toFloat() * sp, Math.sin(a.toDouble()).toFloat() * sp, 18 + Random.nextInt(14), cols[Random.nextInt(cols.size)]))
        }
        play(sBoom, 1f)
    }

    private fun update(w: Int, hh: Int) {
        if (px == 0f) px = w / 2f
        parts.forEach { it.x += it.vx; it.y += it.vy; it.vy += 0.2f; it.life-- }; parts.removeAll { it.life <= 0 }
        if (lives <= 0) return
        val now = System.currentTimeMillis()
        if (now - lastShot > fireMs) { fireWeapon(hh); lastShot = now; play(sShoot, 0.5f) }
        if (now - lastSpawn > curSpawn()) { enemies.add(E(Random.nextFloat() * (w - 80) + 40, -40f, curHp())); lastSpawn = now }
        bullets.forEach { it.y += it.vy; it.x += it.vx }; bullets.removeAll { it.y < 0 || it.x < -20 || it.x > w + 20 }
        enemies.forEach { it.y += curSpeed() }
        val it = enemies.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val hit = bullets.firstOrNull { Math.abs(it.x - e.x) < 40 && Math.abs(it.y - e.y) < 40 }
            if (hit != null) {
                bullets.remove(hit); e.hp -= damage
                if (e.hp <= 0) { it.remove(); score++; explode(e.x, e.y); if (level() > lastLevel) { lastLevel = level(); flash = 90 } }
            } else if (e.y > hh) { it.remove(); lives--; if (lives <= 0) bank() }
        }
    }

    private fun render(c: Canvas) {
        c.drawColor(Color.rgb(10, 10, 25))
        p.color = shipColor; c.drawRect(px - 40, c.height - 140f, px + 40, c.height - 80f, p)
        p.color = if (wIdx == 4) Color.rgb(255, 60, 255) else Color.YELLOW; bullets.forEach { c.drawCircle(it.x, it.y, if (wIdx == 4) 6f else 8f, p) }
        enemies.forEach {
            p.color = when { it.hp >= 4 -> Color.rgb(170, 0, 200); it.hp == 3 -> Color.rgb(255, 90, 0); else -> Color.RED }
            c.drawRect(it.x - 35, it.y - 35, it.x + 35, it.y + 35, p)
        }
        parts.forEach { p.color = it.color; p.alpha = (it.life * 255 / 32).coerceIn(0, 255); c.drawCircle(it.x, it.y, 6f, p) }
        p.alpha = 255
        p.color = Color.WHITE; p.textSize = 52f
        c.drawText("Nivel ${level()}  Puntos: $score  Vidas: $lives", 30f, 90f, p)
        if (flash > 0) { flash--; p.color = Color.YELLOW; p.textSize = 80f; c.drawText("¡NIVEL ${level()}!", c.width / 2f - 200f, c.height / 3f, p); p.textSize = 52f }
        if (lives <= 0) {
            c.drawText("GAME OVER  (+$score monedas)", 40f, c.height / 2f, p)
            c.drawText("Tocá para reiniciar / Atrás: menú", 40f, c.height / 2f + 70f, p)
        }
    }
}
