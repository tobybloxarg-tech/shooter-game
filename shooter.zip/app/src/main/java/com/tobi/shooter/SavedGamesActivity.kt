package com.tobi.shooter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.ScrollView
import android.widget.Toast

class SavedGamesActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        Ui.add(root, Ui.title(this, "PARTIDAS GUARDADAS"))
        Ui.add(root, Ui.text(this, "Continuá desde el punto donde guardaste."))
        if (Save.hasSavedGame(this)) {
            Ui.add(root, Ui.button(this, "▶  CONTINUAR PARTIDA", Color.rgb(30, 150, 80)) {
                startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_LOAD_SAVED, true))
                finish()
            })
            Ui.add(root, Ui.button(this, "BORRAR PARTIDA GUARDADA", Color.rgb(155, 55, 55)) {
                AlertDialog.Builder(this).setTitle("¿Borrar partida?")
                    .setMessage("Esta partida guardada se eliminará.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Borrar") { _, _ -> Save.clearSavedGame(this); Toast.makeText(this, "Partida borrada", Toast.LENGTH_SHORT).show(); recreate() }
                    .show()
            })
        } else {
            Ui.add(root, Ui.text(this, "Todavía no tenés partidas guardadas. Durante una partida, apretá Atrás y elegí Guardar partida."))
        }
        Ui.add(root, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }
}
