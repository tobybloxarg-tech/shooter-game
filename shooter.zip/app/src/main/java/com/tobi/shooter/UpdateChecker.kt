package com.tobi.shooter

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

object UpdateChecker {
    private fun get(url: String): String {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 12000
        connection.readTimeout = 12000
        connection.instanceFollowRedirects = true
        connection.useCaches = false
        connection.setRequestProperty("User-Agent", "TobiShooter-UpdateCheck")
        connection.setRequestProperty("Cache-Control", "no-cache")
        try {
            check(connection.responseCode == 200) { "HTTP ${connection.responseCode}" }
            return connection.inputStream.bufferedReader().use { it.readText() }
        } finally { connection.disconnect() }
    }

    fun isUpdateAvailable(ctx: Context): Boolean {
        val latest = try {
            val value = get("https://github.com/tobybloxarg-tech/shooter-game/releases/download/latest-build/version.txt?t=${System.currentTimeMillis()}").trim().toInt()
            require(value > 0)
            value
        } catch (_: Exception) {
            val json = get("https://api.github.com/repos/tobybloxarg-tech/shooter-game/actions/workflows/build.yml/runs?branch=main&status=success&per_page=1")
            val runs = JSONObject(json).getJSONArray("workflow_runs")
            check(runs.length() > 0)
            runs.getJSONObject(0).getInt("run_number")
        }
        @Suppress("DEPRECATION")
        val installed = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
        return latest > installed
    }
}
