package com.tobi.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView

class BossesActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.root(this)
        Ui.add(root, Ui.title(this, "ENFRENTAR JEFES"))
        Ui.add(root, Ui.text(this, "Elegí un jefe que ya derrotaste. Cada victoria da 100 monedas."))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val maxLevel = Save.maxBossDefeated(this)
        if (maxLevel == 0) {
            Ui.add(list, Ui.text(this, "Todavía no hay jefes guardados. A partir de esta actualización, vencelos en una partida para desbloquearlos acá."))
        } else {
            for (level in 1..maxLevel) {
                val hp = 60 + 40 * level
                Ui.add(list, Ui.button(this, "JEFE $level • NIVEL $level\n$hp de vida — Enfrentar", Color.rgb(170, 45, 100)) {
                    startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_BOSS_LEVEL, level))
                })
            }
        }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.add(root, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(root)
    }
}
