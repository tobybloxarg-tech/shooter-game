package com.tobi.shooter

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.media.AudioAttributes
import android.media.SoundPool
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceView
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import kotlin.random.Random

class GameView(private val ctx: Context, cfg: String, private val replayBossLevel: Int = 0, private val restoringSaved: Boolean = false, private val campaignStage: Int = 0) : SurfaceView(ctx), Runnable {
    private val j = JSONObject(cfg)
    private val enemySpeed = j.optDouble("enemySpeed", 6.0).toFloat()
    private val spawnMs = j.optLong("spawnMs", 700)
    private val wp = Weapons.list[Save.weapon(ctx).coerceIn(0, Weapons.list.size - 1)]
    private var wIdx = Save.weapon(ctx)
    private var fireMs = ((j.optLong("fireMs", 260) - 28L * Save.lvl(ctx, "fire")) * wp.rate).toLong().coerceAtLeast(55)
    private var bonusL = if (Save.bonusGames(ctx) > 0) 2 else 0
    private var dblCoins = Save.dblGames(ctx) > 0
    init {
        if (!restoringSaved) {
            if (Save.bonusGames(ctx) > 0) Save.setBonusGames(ctx, Save.bonusGames(ctx) - 1)
            if (Save.dblGames(ctx) > 0) Save.setDblGames(ctx, Save.dblGames(ctx) - 1)
        }
    }
    private var lives0 = j.optInt("lives", 3) + Save.lvl(ctx, "life") + bonusL
    private var damage = 1 + Save.lvl(ctx, "dmg") + wp.dmg
    private var shipColor = Skins.color(Save.skin(ctx))
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var thread: Thread? = null
    @Volatile private var running = false

    class B(var x: Float, var y: Float, var vx: Float = 0f, var vy: Float = -22f, val hitDamage: Int = 1, val effect: Int = 0)
    class E(var x: Float, var y: Float, var hp: Int)
    class Part(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Int, val color: Int)
    class PowerUp(var x: Float, var y: Float, val bomb: Boolean)
    private val bullets = ArrayList<B>(); private val enemies = ArrayList<E>(); private val parts = ArrayList<Part>()
    private val powerUps = ArrayList<PowerUp>()
    private var lastPowerUpSpawn = 0L
    private var shieldUntil = 0L
    private var lastEmpUse = 0L
    private var lastShieldUse = 0L
    @Volatile private var abilityTouch = false
    @Volatile private var pendingEmp = false
    @Volatile private var pendingShield = false
    private var powerMessage = ""
    private var powerMessageUntil = 0L
    private var activeMs = 0L
    private var lastActiveFrame = 0L
    private var px = 0f; private var score = 0; private var lives = lives0; private var banked = 0
    @Volatile private var noMoveUntil = 0L
    private var noFireUntil = 0L
    @Volatile private var stickX = 0f
    @Volatile private var dpadLeft = false
    @Volatile private var dpadRight = false
    private var lastControllerFrame = 0L
    private var lastShot = 0L; private var lastSpawn = 0L
    private fun level() = 1 + score / 10
    private fun curSpeed() = (enemySpeed + 0.45f * (level() - 1)).coerceAtMost(enemySpeed * 3.2f)
    private fun curSpawn() = (spawnMs - 35L * (level() - 1)).coerceAtLeast(230L)
    private fun curHp() = 2 + (level() - 1) / 3
    class Boss(var x: Float, var y: Float, var hp: Int, val maxHp: Int, var dir: Float, val num: Int, var lastFire: Long, val bornAt: Long = System.currentTimeMillis(), var shotCount: Int = 0)
    private var boss: Boss? = null
    private val eBullets = ArrayList<B>()
    private var enemiesDefeated = 0
    private var bossesDefeated = 0
    private var replayWon = false
    private var campaignBossSpawned = false
    private var campaignResult = ""
    private var bossFlash = 0
    private var bossShotFlashUntil = 0L
    private var bossHitFlashUntil = 0L
    private var lastBossHitSoundAt = 0L
    private var hurt = 0
    private var flash = 0
    private var lastLevel = 1

    private val pool = SoundPool.Builder().setMaxStreams(10)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build()
    private var sShoot = 0; private var sBoom = 0
    private var sBossIntro = 0; private var sBossShot = 0; private var sBossHit = 0
    private val loadedSounds = HashSet<Int>()
    @Volatile private var bossIntroWaiting = false
    private val sfxOn = Save.sfx(ctx)

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        requestFocus()
        val d = Save.dataDir(ctx)
        File(d, "shoot.wav").takeIf { it.exists() }?.let { sShoot = pool.load(it.path, 1) }
        File(d, "explosion.wav").takeIf { it.exists() }?.let { sBoom = pool.load(it.path, 1) }
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                var playIntroNow = false
                synchronized(loadedSounds) {
                    loadedSounds.add(sampleId)
                    if (sampleId == sBossIntro && bossIntroWaiting) {
                        bossIntroWaiting = false
                        playIntroNow = true
                    }
                }
                if (playIntroNow && sfxOn) pool.play(sampleId, 1f, 1f, 2, 0, 1f)
            }
        }
        sBossIntro = pool.load(ctx, R.raw.boss_intro, 1)
        sBossShot = pool.load(ctx, R.raw.boss_shot, 1)
        sBossHit = pool.load(ctx, R.raw.boss_hit, 1)
    }
    private fun play(id: Int, vol: Float) {
        if (sfxOn && id != 0) pool.play(id, vol, vol, 1, 0, 1f)
    }
    private fun playBossIntro() {
        if (!sfxOn || sBossIntro == 0) return
        val ready = synchronized(loadedSounds) {
            if (loadedSounds.contains(sBossIntro)) true
            else { bossIntroWaiting = true; false }
        }
        if (ready) pool.play(sBossIntro, 1f, 1f, 2, 0, 1f)
    }

    private var lastPlayCheckpoint = 0L
    private var pausedAtWall = 0L
    fun start() {
        if (running) return
        val now = System.currentTimeMillis()
        if (pausedAtWall != 0L) {
            val delta = (now - pausedAtWall).coerceAtLeast(0L)
            if (noMoveUntil > pausedAtWall) noMoveUntil += delta
            if (noFireUntil > pausedAtWall) noFireUntil += delta
            if (lastShot != 0L) lastShot += delta
            if (lastSpawn != 0L) lastSpawn += delta
            boss?.let { it.lastFire += delta }
            pausedAtWall = 0L
        }
        running = true
        lastPlayCheckpoint = SystemClock.elapsedRealtime()
        lastActiveFrame = 0L
        lastControllerFrame = 0L
        thread = Thread(this).also { it.start() }
    }
    fun stop() {
        if (!running) return
        running = false
        thread?.join()
        thread = null
        checkpointPlayTime(force = true)
        pausedAtWall = System.currentTimeMillis()
        stickX = 0f; dpadLeft = false; dpadRight = false
    }
    fun canSave() = lives > 0 && !replayWon
    fun settleEarnings() { bank() }

    @Synchronized
    private fun checkpointPlayTime(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        val elapsed = now - lastPlayCheckpoint
        if (elapsed > 0L && (force || elapsed >= 1000L)) {
            Save.addPlayMs(ctx, elapsed)
            lastPlayCheckpoint = now
        }
    }
    @Synchronized
    fun exportSavedState(): String {
        val now = if (pausedAtWall != 0L) pausedAtWall else System.currentTimeMillis()
        val root = JSONObject()
            .put("format", "tobi-shooter-run")
            .put("version", 1)
            .put("replayBossLevel", replayBossLevel).put("campaignStage", campaignStage)
            .put("campaignBossSpawned", campaignBossSpawned).put("campaignResult", campaignResult)
            .put("bonusL", bonusL).put("dblCoins", dblCoins)
            .put("weapon", wIdx).put("fireMs", fireMs).put("damage", damage).put("shipColor", shipColor).put("lives0", lives0)
            .put("px", px.toDouble()).put("score", score).put("lives", lives).put("banked", banked)
            .put("activeMs", activeMs).put("lastPowerUpSpawn", lastPowerUpSpawn)
            .put("shieldLeft", (shieldUntil - activeMs).coerceAtLeast(0L))
            .put("empCooldownLeft", empCooldownLeft()).put("shieldCooldownLeft", shieldCooldownLeft())
            .put("powerMessage", powerMessage).put("powerMessageLeft", (powerMessageUntil - activeMs).coerceAtLeast(0L))
            .put("noMoveLeft", (noMoveUntil - now).coerceAtLeast(0L)).put("noFireLeft", (noFireUntil - now).coerceAtLeast(0L))
            .put("lastShotAge", if (lastShot == 0L) Long.MAX_VALUE else (now-lastShot).coerceAtLeast(0L))
            .put("lastSpawnAge", if (lastSpawn == 0L) Long.MAX_VALUE else (now-lastSpawn).coerceAtLeast(0L))
            .put("enemiesDefeated", enemiesDefeated).put("bossesDefeated", bossesDefeated)
            .put("lastLevel", lastLevel).put("flash", flash).put("bossFlash", bossFlash)
            .put("replayWon", replayWon)
        fun bulletJson(b: B) = JSONObject().put("x",b.x.toDouble()).put("y",b.y.toDouble()).put("vx",b.vx.toDouble()).put("vy",b.vy.toDouble()).put("damage",b.hitDamage).put("effect",b.effect)
        val aBullets=JSONArray(); bullets.forEach { aBullets.put(bulletJson(it)) }; root.put("bullets",aBullets)
        val aEnemyBullets=JSONArray(); eBullets.forEach { aEnemyBullets.put(bulletJson(it)) }; root.put("enemyBullets",aEnemyBullets)
        val aEnemies=JSONArray(); enemies.forEach { aEnemies.put(JSONObject().put("x",it.x.toDouble()).put("y",it.y.toDouble()).put("hp",it.hp)) }; root.put("enemies",aEnemies)
        val aParts=JSONArray(); parts.forEach { aParts.put(JSONObject().put("x",it.x.toDouble()).put("y",it.y.toDouble()).put("vx",it.vx.toDouble()).put("vy",it.vy.toDouble()).put("life",it.life).put("color",it.color)) }; root.put("parts",aParts)
        val aPower=JSONArray(); powerUps.forEach { aPower.put(JSONObject().put("x",it.x.toDouble()).put("y",it.y.toDouble()).put("bomb",it.bomb)) }; root.put("powerUps",aPower)
        val b=boss
        if (b!=null) root.put("boss",JSONObject().put("x",b.x.toDouble()).put("y",b.y.toDouble()).put("hp",b.hp).put("maxHp",b.maxHp).put("dir",b.dir.toDouble()).put("num",b.num).put("lastFireAge",(now-b.lastFire).coerceAtLeast(0L)).put("bornAge",(now-b.bornAt).coerceAtLeast(0L)).put("shotCount",b.shotCount))
        return root.toString()
    }

    fun restoreSavedState(json: String): Boolean {
        return try {
            val root=JSONObject(json)
            if(root.optString("format")!="tobi-shooter-run" || root.optInt("version",-1)!=1) return false
            val now=System.currentTimeMillis()
            bonusL=root.optInt("bonusL",bonusL).coerceIn(0,2); dblCoins=root.optBoolean("dblCoins",dblCoins)
            lives0=root.optInt("lives0",j.optInt("lives",3)+Save.lvl(ctx,"life")+bonusL).coerceIn(1,1000)
            wIdx=root.optInt("weapon",wIdx).coerceIn(0,Weapons.list.size-1)
            fireMs=root.optLong("fireMs",fireMs).coerceIn(55L,10000L)
            damage=root.optInt("damage",damage).coerceIn(1,10000)
            shipColor=root.optInt("shipColor",shipColor)
            px=root.optDouble("px",0.0).toFloat(); score=root.optInt("score",0).coerceAtLeast(0)
            lives=root.optInt("lives",lives0).coerceIn(0,lives0); banked=root.optInt("banked",0).coerceIn(0,score)
            activeMs=root.optLong("activeMs",0L).coerceAtLeast(0L); lastActiveFrame=0L
            lastPowerUpSpawn=root.optLong("lastPowerUpSpawn",0L).coerceAtLeast(0L)
            shieldUntil=activeMs+root.optLong("shieldLeft",0L).coerceIn(0L,12000L)
            restoreCooldown(root.optLong("empCooldownLeft",0L), true)
            restoreCooldown(root.optLong("shieldCooldownLeft",0L), false)
            powerMessage=root.optString("powerMessage",""); powerMessageUntil=activeMs+root.optLong("powerMessageLeft",0L).coerceIn(0L,10000L)
            noMoveUntil=now+root.optLong("noMoveLeft",0L).coerceIn(0L,2000L); noFireUntil=now+root.optLong("noFireLeft",0L).coerceIn(0L,2500L)
            lastShot=if(root.optLong("lastShotAge",Long.MAX_VALUE)==Long.MAX_VALUE) 0L else now-root.optLong("lastShotAge",0L).coerceAtLeast(0L)
            lastSpawn=if(root.optLong("lastSpawnAge",Long.MAX_VALUE)==Long.MAX_VALUE) 0L else now-root.optLong("lastSpawnAge",0L).coerceAtLeast(0L)
            enemiesDefeated=root.optInt("enemiesDefeated",0).coerceAtLeast(0); bossesDefeated=root.optInt("bossesDefeated",0).coerceAtLeast(0)
            lastLevel=root.optInt("lastLevel",1).coerceAtLeast(1); flash=root.optInt("flash",0).coerceIn(0,90); bossFlash=root.optInt("bossFlash",0).coerceIn(0,120)
            replayWon=root.optBoolean("replayWon",false)
            campaignBossSpawned=root.optBoolean("campaignBossSpawned",false)
            campaignResult=root.optString("campaignResult", "")
            fun readBullets(key:String, target:ArrayList<B>) { val a=root.optJSONArray(key)?:return; for(i in 0 until minOf(a.length(),500)) { val o=a.optJSONObject(i)?:continue; target.add(B(o.optDouble("x").toFloat(),o.optDouble("y").toFloat(),o.optDouble("vx").toFloat(),o.optDouble("vy",-22.0).toFloat(),o.optInt("damage",1).coerceIn(1,10),o.optInt("effect",0).coerceIn(0,2))) } }
            readBullets("bullets",bullets); readBullets("enemyBullets",eBullets)
            root.optJSONArray("enemies")?.let { a->for(i in 0 until minOf(a.length(),300)){val o=a.optJSONObject(i)?:continue;enemies.add(E(o.optDouble("x").toFloat(),o.optDouble("y").toFloat(),o.optInt("hp",1).coerceAtLeast(1))) } }
            root.optJSONArray("parts")?.let { a->for(i in 0 until minOf(a.length(),800)){val o=a.optJSONObject(i)?:continue;parts.add(Part(o.optDouble("x").toFloat(),o.optDouble("y").toFloat(),o.optDouble("vx").toFloat(),o.optDouble("vy").toFloat(),o.optInt("life",1).coerceIn(1,60),o.optInt("color",Color.WHITE))) } }
            root.optJSONArray("powerUps")?.let { a->for(i in 0 until minOf(a.length(),20)){val o=a.optJSONObject(i)?:continue;powerUps.add(PowerUp(o.optDouble("x").toFloat(),o.optDouble("y").toFloat(),o.optBoolean("bomb"))) } }
            root.optJSONObject("boss")?.let { o-> val hp=o.optInt("hp",1).coerceAtLeast(1); boss=Boss(o.optDouble("x").toFloat(),o.optDouble("y").toFloat(),hp,o.optInt("maxHp",hp).coerceAtLeast(hp),o.optDouble("dir",1.0).toFloat(),o.optInt("num",1).coerceAtLeast(1),now-o.optLong("lastFireAge",0L).coerceAtLeast(0L),now-o.optLong("bornAge",0L).coerceAtLeast(0L),o.optInt("shotCount",0).coerceAtLeast(0)) }
            lastControllerFrame=0L; stickX=0f; dpadLeft=false; dpadRight=false
            pausedAtWall=now
            true
        } catch (_:Exception) { false }
    }

    fun release() { bossIntroWaiting = false; pool.setOnLoadCompleteListener(null); pool.release() }

    private fun bank() {
        val gain = score - banked
        if (gain > 0) {
            val multiplierPercent = 100 + 10 * Save.lvl(ctx, "coinBonus").coerceIn(0, 5)
            val payout = gain.toLong() * multiplierPercent / 100L
            Save.addCoins(ctx, (if (dblCoins) payout * 2L else payout).coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            banked = score
        }
        if (score > Save.best(ctx)) Save.setBest(ctx, score)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestFocus()
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_X).coerceIn(-1f, 1f)
            val hat = e.getAxisValue(MotionEvent.AXIS_HAT_X).coerceIn(-1f, 1f)
            stickX = (if (kotlin.math.abs(x) > kotlin.math.abs(hat)) x else hat)
                .let { if (kotlin.math.abs(it) < 0.18f) 0f else it }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { dpadLeft = true; return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { dpadRight = true; return true }
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_START -> {
                if (lives <= 0 && event.repeatCount == 0) restartGame()
                    return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { dpadLeft = false; return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { dpadRight = false; return true }
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_START -> return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun restartGame() {
        lives = lives0; score = 0; banked = 0; lastLevel = 1; flash = 0; boss = null
        lastEmpUse = 0L; lastShieldUse = 0L; pendingEmp = false; pendingShield = false
        enemiesDefeated = 0; bossesDefeated = 0; replayWon = false; campaignBossSpawned = false; campaignResult = ""; bossFlash = 0; hurt = 0; eBullets.clear(); bullets.clear()
        noMoveUntil = 0L; noFireUntil = 0L
        enemies.clear(); parts.clear(); powerUps.clear(); shieldUntil = 0L; activeMs = 0L
        lastActiveFrame = 0L; lastPowerUpSpawn = 0L; powerMessageUntil = 0L
        lastControllerFrame = 0L
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val buttonY = height - 250f
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                if (lives <= 0) { restartGame(); abilityTouch = false; return true }
                val inAbilityRow = e.y in (buttonY - 70f)..(buttonY + 70f)
                if (inAbilityRow && e.x < width * 0.28f) {
                    abilityTouch = true; pendingEmp = true; return true
                }
                if (inAbilityRow && e.x > width * 0.72f) {
                    abilityTouch = true; pendingShield = true; return true
                }
                abilityTouch = false
                if (System.currentTimeMillis() >= noMoveUntil) px = e.x.coerceIn(45f, (width - 45).coerceAtLeast(45).toFloat())
            }
            MotionEvent.ACTION_MOVE -> if (!abilityTouch && System.currentTimeMillis() >= noMoveUntil) px = e.x.coerceIn(45f, (width - 45).coerceAtLeast(45).toFloat())
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> abilityTouch = false
        }
        return true
    }

    private fun empRank() = Save.lvl(ctx, "emp")
    private fun shieldSkillRank() = Save.lvl(ctx, "shieldSkill")
    private fun empCooldownMs() = (30_000L - (empRank() - 1).coerceAtLeast(0) * 5_000L).coerceAtLeast(15_000L)
    private fun shieldCooldownMs() = (45_000L - (shieldSkillRank() - 1).coerceAtLeast(0) * 5_000L).coerceAtLeast(30_000L)
    private fun empCooldownLeft() = if (lastEmpUse <= 0L) 0L else (empCooldownMs() - (activeMs - lastEmpUse)).coerceAtLeast(0L)
    private fun shieldCooldownLeft() = if (lastShieldUse <= 0L) 0L else (shieldCooldownMs() - (activeMs - lastShieldUse)).coerceAtLeast(0L)
    private fun restoreCooldown(left: Long, emp: Boolean) {
        val cooldown = if (emp) empCooldownMs() else shieldCooldownMs()
        val remaining = left.coerceIn(0L, cooldown)
        val usedAt = if (remaining > 0L) activeMs - (cooldown - remaining) else 0L
        if (emp) lastEmpUse = usedAt else lastShieldUse = usedAt
    }
    private fun useEmp() {
        val rank = empRank()
        if (rank <= 0) { powerMessage = "PULSO EMP: desbloquealo en MEJORAS"; powerMessageUntil = activeMs + 2200L; return }
        val left = empCooldownLeft()
        if (left > 0L) { powerMessage = "EMP recargando: ${((left + 999L) / 1000L)}s"; powerMessageUntil = activeMs + 1600L; return }
        lastEmpUse = activeMs.coerceAtLeast(1L)
        eBullets.clear()
        val cleared = enemies.toList()
        enemies.clear()
        cleared.forEach { explode(it.x, it.y) }
        score += cleared.size
        enemiesDefeated += cleared.size
        boss?.let { target -> target.hp = (target.hp - (20 + 15 * rank)).coerceAtLeast(0) }
        powerMessage = "¡PULSO EMP! MAPA DESPEJADO"
        powerMessageUntil = activeMs + 2000L
        if (level() > lastLevel) { lastLevel = level(); flash = 90 }
    }
    private fun useActiveShield() {
        val rank = shieldSkillRank()
        if (rank <= 0) { powerMessage = "ESCUDO ACTIVO: desbloquealo en MEJORAS"; powerMessageUntil = activeMs + 2200L; return }
        val left = shieldCooldownLeft()
        if (left > 0L) { powerMessage = "Escudo recargando: ${((left + 999L) / 1000L)}s"; powerMessageUntil = activeMs + 1600L; return }
        lastShieldUse = activeMs.coerceAtLeast(1L)
        shieldUntil = maxOf(shieldUntil, activeMs + 4000L + 2000L * (rank - 1))
        powerMessage = "¡ESCUDO ACTIVO!"
        powerMessageUntil = activeMs + 1800L
    }

    override fun run() {
        while (running) {
            checkpointPlayTime()
            val h = holder
            if (!h.surface.isValid) continue
            val c = h.lockCanvas() ?: continue
            try { update(c.width, c.height); render(c) } finally { h.unlockCanvasAndPost(c) }
            Thread.sleep(16)
        }
    }

    private fun fireWeapon(hh: Int) {
        val y = hh - 160f
        when (wIdx) {
            1 -> { bullets.add(B(px - 22, y)); bullets.add(B(px + 22, y)) }
            3 -> { bullets.add(B(px, y)); bullets.add(B(px, y, -4f, -21f)); bullets.add(B(px, y, 4f, -21f)) }
            4 -> { bullets.add(B(px - 14, y, 0f, -32f)); bullets.add(B(px + 14, y, 0f, -32f)) }
            5 -> {
                bullets.add(B(px, y, 0f, -20f))
                bullets.add(B(px - 12, y, -4f, -20f)); bullets.add(B(px + 12, y, 4f, -20f))
                bullets.add(B(px - 22, y, -8f, -18f)); bullets.add(B(px + 22, y, 8f, -18f))
            }
            6 -> bullets.add(B(px, y, 0f, -34f))
            7 -> bullets.add(B(px, y, 0f, -18f))
            8 -> {
                bullets.add(B(px - 15f, y, -5f, -24f))
                bullets.add(B(px + 15f, y, 5f, -24f))
            }
            9 -> {
                bullets.add(B(px, y, 0f, -23f)); bullets.add(B(px - 16f, y, -6f, -21f)); bullets.add(B(px + 16f, y, 6f, -21f))
            }
            10 -> {
                bullets.add(B(px, y, 0f, -22f)); bullets.add(B(px - 12f, y, -4f, -21f)); bullets.add(B(px + 12f, y, 4f, -21f))
                bullets.add(B(px - 24f, y, -8f, -18f)); bullets.add(B(px + 24f, y, 8f, -18f))
            }
            11 -> {
                bullets.add(B(px - 14f, y, -3f, -30f)); bullets.add(B(px + 14f, y, 3f, -30f))
            }
            else -> bullets.add(B(px, y))
        }
    }

    private fun explode(x: Float, y: Float) {
        val cols = intArrayOf(Color.YELLOW, Color.rgb(255, 140, 0), Color.RED, Color.WHITE)
        repeat(26) {
            val a = Random.nextFloat() * 6.283f; val sp = 3f + Random.nextFloat() * 11f
            parts.add(Part(x, y, Math.cos(a.toDouble()).toFloat() * sp, Math.sin(a.toDouble()).toFloat() * sp, 18 + Random.nextInt(14), cols[Random.nextInt(cols.size)]))
        }
        play(sBoom, 1f)
    }

    private fun defeatBoss(target: Boss) {
        repeat(6) { explode(target.x + Random.nextInt(-100, 100), target.y + Random.nextInt(-50, 50)) }
        Save.recordBossDefeated(ctx, target.num)
        Save.addCoins(ctx, 100)
        powerMessage = "¡JEFE DERROTADO! +100 MONEDAS"
        powerMessageUntil = activeMs + 3_000L
        if (replayBossLevel > 0) {
            replayWon = true
            postDelayed({ (ctx as? android.app.Activity)?.finish() }, 2_500L)
        } else {
            score += 10
            if (campaignStage in 1..3) {
                if (campaignStage < 3) {
                    Save.unlockStage(ctx, campaignStage + 1)
                    campaignResult = "¡FASE $campaignStage COMPLETADA!|FASE ${campaignStage + 1} DESBLOQUEADA"
                } else {
                    campaignResult = "¡JUEGO COMPLETADO!|DERROTASTE AL JEFE FINAL"
                }
                replayWon = true
                bank()
                postDelayed({ (ctx as? android.app.Activity)?.finish() }, 5_000L)
            }
        }
        boss = null
        eBullets.clear()
        if (level() > lastLevel) { lastLevel = level(); flash = 90 }
    }

    private fun detonateBomb() {
        val cleared = enemies.toList()
        for (enemy in cleared) explode(enemy.x, enemy.y)
        enemies.clear()
        score += cleared.size
        enemiesDefeated += cleared.size
        val target = boss
        if (target != null) defeatBoss(target) else {
            powerMessage = "¡BOMBA! MAPA LIMPIO"
            powerMessageUntil = activeMs + 2_000L
        }
        eBullets.clear()
        if (level() > lastLevel) { lastLevel = level(); flash = 90 }
    }

    private fun update(w: Int, hh: Int) {
        if (px == 0f) px = w / 2f
        parts.forEach { it.x += it.vx; it.y += it.vy; it.vy += 0.2f; it.life-- }; parts.removeAll { it.life <= 0 }
        if (lives <= 0 || replayWon) return
        val now = System.currentTimeMillis()
        val frameTime = SystemClock.elapsedRealtime()
        if (lastActiveFrame != 0L) activeMs += frameTime - lastActiveFrame
        lastActiveFrame = frameTime
        if (lastControllerFrame != 0L) {
            val dt = (frameTime - lastControllerFrame).coerceIn(0L, 40L)
            val direction = stickX + (if (dpadRight) 1f else 0f) - (if (dpadLeft) 1f else 0f)
            if (now >= noMoveUntil && kotlin.math.abs(direction) > 0.01f) px = (px + direction.coerceIn(-1f, 1f) * w * 1.15f * dt / 1000f).coerceIn(45f, w - 45f)
        }
        lastControllerFrame = frameTime
        if (pendingEmp) { pendingEmp = false; useEmp() }
        if (pendingShield) { pendingShield = false; useActiveShield() }
        if (now >= noFireUntil && now - lastShot > fireMs) { fireWeapon(hh); lastShot = now; play(sShoot, 0.5f) }
        if (activeMs - lastPowerUpSpawn >= 60_000L) {
            powerUps.add(PowerUp(w * 0.25f, -45f, false))
            powerUps.add(PowerUp(w * 0.75f, -45f, true))
            lastPowerUpSpawn = activeMs
        }
        powerUps.forEach { it.y += 4.2f }
        val caught = powerUps.filter { it.y in (hh - 190f)..(hh - 55f) && Math.abs(it.x - px) < 70f }
        for (item in caught) {
            powerUps.remove(item)
            if (item.bomb) detonateBomb() else {
                shieldUntil = activeMs + 12_000L
                powerMessage = "¡ESCUDO ACTIVADO!"
                powerMessageUntil = activeMs + 2_000L
            }
        }
        powerUps.removeAll { it.y > hh + 30f }
        if (replayWon) return
        if (replayBossLevel > 0 && boss == null && enemiesDefeated == 0) {
            val hp = 60 + 40 * replayBossLevel
            boss = Boss(w / 2f, -150f, hp, hp, 1f, replayBossLevel, now)
            bossFlash = 120
            playBossIntro()
        }
        if (replayBossLevel == 0 && boss == null && campaignStage in 1..3 && !campaignBossSpawned && enemiesDefeated >= 300) {
            campaignBossSpawned = true
            val hp = 60 + 40 * campaignStage
            boss = Boss(w / 2f, -150f, hp, hp, 1f, campaignStage, now)
            bossFlash = 120
            powerMessage = "¡300 ENEMIGOS! JEFE DE FASE ${campaignStage}"
            powerMessageUntil = activeMs + 3_000L
            playBossIntro()
        } else if (replayBossLevel == 0 && campaignStage == 0 && boss == null && enemiesDefeated > 0 && bossesDefeated < enemiesDefeated / 300) {
            bossesDefeated++
            val n = bossesDefeated
            val hp = 60 + 40 * n
            boss = Boss(w / 2f, -150f, hp, hp, 1f, n, now)
            bossFlash = 120
            playBossIntro()
        }
        val bs = boss
        if (bs != null) {
            if (bs.y < 260f) bs.y += 3f
            else {
                val bossSpeed = (3f + bs.num * 0.7f).coerceAtMost(9f)
                bs.x += bs.dir * bossSpeed
                if (bs.x < 140f) bs.dir = 1f
                if (bs.x > w - 140f) bs.dir = -1f
            }
            val fireInterval = (1250L - 55L * bs.num).coerceAtLeast(380L)
            if (bs.y >= 260f && now - bs.lastFire > fireInterval) {
                bs.lastFire = now
                bossShotFlashUntil = now + 190L
                play(sBossShot, 0.82f)
                val shotSpeed = (9f + bs.num * 0.55f).coerceAtMost(15f)
                bs.shotCount++
                val statusEffect = if (bs.shotCount % 3 == 0) {
                    if ((bs.shotCount / 3) % 2 == 1) 1 else 2
                } else 0
                if (statusEffect != 0) {
                    val sx = bs.x; val sy = bs.y + 65f
                    val dx = px - sx; val dy = (hh - 110f) - sy
                    val distance = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtLeast(1f)
                    val specialSpeed = (7.2f + bs.num * 0.2f).coerceAtMost(9f)
                    eBullets.add(B(sx, sy, dx / distance * specialSpeed, dy / distance * specialSpeed,
                        (1 + (bs.num - 1) / 3).coerceAtMost(3), statusEffect))
                } else {
                    val pairCount = (bs.num - 1).coerceIn(0, 6)
                    for (i in -pairCount..pairCount) {
                        val vx = i * (1.5f + bs.num * 0.18f)
                        eBullets.add(B(bs.x + i * 14f, bs.y + 65f, vx, shotSpeed, (1 + (bs.num - 1) / 3).coerceAtMost(3)))
                    }
                }
            }
            val bh = bullets.filter { Math.abs(it.x - bs.x) < 120 && Math.abs(it.y - bs.y) < 75 }
            if (bh.isNotEmpty()) {
                for (b in bh) {
                    bullets.remove(b); bs.hp -= damage; hurt = 8
                    repeat(5) {
                        val a = Random.nextFloat() * 6.283f
                        val sp = 2f + Random.nextFloat() * 7f
                        parts.add(Part(b.x, b.y, Math.cos(a.toDouble()).toFloat() * sp, Math.sin(a.toDouble()).toFloat() * sp, 12 + Random.nextInt(10), if (Random.nextBoolean()) Color.CYAN else Color.WHITE))
                    }
                }
                bossHitFlashUntil = now + 180L
                if (now - lastBossHitSoundAt > 100L) { play(sBossHit, 0.9f); lastBossHitSoundAt = now }
            }
            if (bs.hp <= 0) defeatBoss(bs)
        }
        if (replayWon) return
        eBullets.forEach { it.y += it.vy; it.x += it.vx }
        val hit2 = eBullets.filter { it.y > hh - 150 && it.y < hh - 70 && Math.abs(it.x - px) < 50 }
        for (b in hit2) {
            eBullets.remove(b)
            if (activeMs >= shieldUntil) {
                lives = (lives - b.hitDamage).coerceAtLeast(0)
                when (b.effect) {
                    1 -> { noMoveUntil = now + 2_000L }
                    2 -> { noFireUntil = now + 2_500L }
                }
                explode(px, hh - 110f)
                if (lives <= 0) bank()
            }
        }
        eBullets.removeAll { it.y > hh + 20 || it.x < -30 || it.x > w + 30 }
        if (lives <= 0) return
        val campaignCanSpawn = campaignStage !in 1..3 || (!campaignBossSpawned && enemiesDefeated < 300)
        if (replayBossLevel == 0 && campaignCanSpawn && now - lastSpawn > curSpawn() * (if (boss != null) 3 else 1)) { enemies.add(E(Random.nextFloat() * (w - 80) + 40, -40f, curHp())); lastSpawn = now }
        bullets.forEach { it.y += it.vy; it.x += it.vx }; bullets.removeAll { it.y < 0 || it.x < -20 || it.x > w + 20 }
        enemies.forEach { it.y += curSpeed() }
        val it = enemies.iterator()
        while (it.hasNext()) {
            val e = it.next()
            val hit = bullets.firstOrNull {
                val reach = when (wIdx) { 7 -> 64; 8, 9, 11 -> 56; 10 -> 48; else -> 40 }
                val verticalReach = when (wIdx) { 7, 11 -> 56; 9, 10 -> 46; else -> 40 }
                Math.abs(it.x - e.x) < reach && Math.abs(it.y - e.y) < verticalReach
            }
            if (hit != null) {
                bullets.remove(hit); e.hp -= damage
                if (e.hp <= 0) { it.remove(); score++; enemiesDefeated++; explode(e.x, e.y); if (level() > lastLevel) { lastLevel = level(); flash = 90 } }
            } else if (e.y > hh) { it.remove(); if (activeMs >= shieldUntil) { lives--; if (lives <= 0) bank() } }
        }
    }

    private fun drawCampaignMap(c: Canvas) {
        val w = c.width.toFloat(); val h = c.height.toFloat()
        val bg = when (campaignStage) { 2 -> Color.rgb(34, 12, 8); 3 -> Color.rgb(20, 8, 40); else -> Color.rgb(8, 16, 38) }
        c.drawColor(bg)
        if (campaignStage == 0) {
            for (i in 0 until 42) { val x=((i*97+31)%w.toInt().coerceAtLeast(1)).toFloat(); val y=((i*173+29)%h.toInt().coerceAtLeast(1)).toFloat(); p.color=Color.rgb(110,130,180); c.drawCircle(x,y,if(i%5==0) 3f else 1.5f,p) }
            return
        }
        // Each campaign phase has a distinct illustrated backdrop.
        when (campaignStage) {
            1 -> {
                p.color=Color.rgb(20,65,115); c.drawCircle(w*.76f,h*.30f,w*.20f,p)
                p.style=Paint.Style.STROKE;p.strokeWidth=5f;p.color=Color.rgb(90,190,230);c.drawOval(w*.46f,h*.25f,w*1.05f,h*.37f,p);p.style=Paint.Style.FILL
                p.color=Color.rgb(18,38,70);c.drawRect(0f,h*.68f,w,h,p)
                for(i in 0..5){p.color=Color.rgb(35,95,145);c.drawRect(i*w/6,h*.69f,(i+1)*w/6-5,h*.71f,p)}
            }
            2 -> {
                p.color=Color.rgb(110,32,15);c.drawCircle(w*.22f,h*.32f,w*.25f,p)
                p.color=Color.rgb(245,95,18);c.drawCircle(w*.22f,h*.32f,w*.19f,p)
                p.color=Color.rgb(255,170,45);c.drawCircle(w*.18f,h*.29f,w*.055f,p)
                p.color=Color.rgb(65,19,13);c.drawRect(0f,h*.72f,w,h,p)
                for(i in 0..4){p.color=Color.rgb(180,55,20);c.drawRect(i*w/5,h*.74f,(i+1)*w/5-7,h*.755f,p)}
            }
            3 -> {
                p.color=Color.rgb(62,25,105);c.drawCircle(w*.70f,h*.31f,w*.26f,p)
                p.color=Color.rgb(33,57,135);c.drawCircle(w*.76f,h*.28f,w*.17f,p)
                p.color=Color.rgb(115,35,150);c.drawCircle(w*.15f,h*.53f,w*.12f,p)
                p.style=Paint.Style.STROKE;p.strokeWidth=4f;p.color=Color.rgb(190,120,255);c.drawOval(w*.46f,h*.23f,w*.98f,h*.39f,p);p.style=Paint.Style.FILL
                p.color=Color.rgb(32,18,64);c.drawRect(0f,h*.77f,w,h,p)
            }
        }
        for(i in 0 until 34){val x=((i*113+47)%w.toInt().coerceAtLeast(1)).toFloat();val y=((i*191+71)% (h*.66f).toInt().coerceAtLeast(1)).toFloat();p.color=if(campaignStage==2) Color.rgb(255,180,90) else Color.rgb(175,210,255);c.drawCircle(x,y,if(i%7==0)3f else 1.5f,p)}
    }

    private fun drawAbility(c: Canvas, x: Float, y: Float, name: String, rank: Int, cooldown: Long, color: Int) {
        p.color = if (rank > 0 && cooldown <= 0L) color else Color.rgb(75, 80, 100)
        p.alpha = 225; c.drawRoundRect(x - 68f, y - 48f, x + 68f, y + 48f, 22f, 22f, p); p.alpha = 255
        p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.textSize = 27f
        c.drawText(name, x, y - 5f, p)
        p.textSize = 19f
        c.drawText(if (rank <= 0) "🔒 MEJORAS" else if (cooldown <= 0L) "LISTO" else "${(cooldown + 999L) / 1000L}s", x, y + 24f, p)
        p.textAlign = Paint.Align.LEFT
    }

    private fun render(c: Canvas) {
        drawCampaignMap(c)
        if (activeMs < shieldUntil) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = Color.CYAN
            c.drawCircle(px, c.height - 110f, 58f, p); p.style = Paint.Style.FILL
        }
        // Nave en forma de cúpula con piso/base plana.
        val shipBase = c.height - 82f
        val dome = Path().apply {
            moveTo(px - 42f, shipBase - 10f)
            arcTo(android.graphics.RectF(px - 42f, shipBase - 62f, px + 42f, shipBase + 22f), 180f, 180f)
            lineTo(px + 42f, shipBase)
            lineTo(px - 42f, shipBase)
            close()
        }
        p.color = shipColor
        c.drawPath(dome, p)
        p.color = Color.rgb(225, 235, 255)
        c.drawRoundRect(px - 46f, shipBase - 10f, px + 46f, shipBase + 2f, 4f, 4f, p)
        p.color = shipColor
        c.drawRect(px - 38f, shipBase + 2f, px + 38f, shipBase + 8f, p)
        drawAbility(c, c.width * 0.16f, c.height - 250f, "EMP", empRank(), empCooldownLeft(), Color.rgb(90, 190, 255))
        drawAbility(c, c.width * 0.84f, c.height - 250f, "ESCUDO", shieldSkillRank(), shieldCooldownLeft(), Color.rgb(80, 220, 170))
        for (item in powerUps) {
            p.color = if (item.bomb) Color.rgb(255, 100, 35) else Color.CYAN
            c.drawCircle(item.x, item.y, 30f, p)
            p.color = Color.WHITE; p.textSize = 32f; p.textAlign = Paint.Align.CENTER
            c.drawText(if (item.bomb) "B" else "E", item.x, item.y + 11f, p)
        }
        p.textAlign = Paint.Align.LEFT
        p.color = when (wIdx) {
            4 -> Color.rgb(255, 60, 255)
            5 -> Color.rgb(255, 170, 45)
            6 -> Color.rgb(40, 255, 220)
            7 -> Color.rgb(255, 70, 70)
            8 -> Color.rgb(255, 220, 90)
            9 -> Color.rgb(255, 100, 25)
            10 -> Color.rgb(100, 220, 255)
            11 -> Color.rgb(190, 90, 255)
            else -> Color.YELLOW
        }
        bullets.forEach {
            when (wIdx) {
                6 -> c.drawRoundRect(it.x - 9f, it.y - 18f, it.x + 9f, it.y + 18f, 8f, 8f, p)
                7 -> {
                    c.save()
                    c.drawRoundRect(it.x - 6f, it.y - 30f, it.x + 6f, it.y + 24f, 4f, 4f, p)
                    p.color = Color.WHITE; c.drawRect(it.x - 2f, it.y - 24f, it.x + 2f, it.y + 14f, p)
                    p.color = Color.rgb(255, 70, 70); c.drawRect(it.x - 10f, it.y + 18f, it.x + 10f, it.y + 23f, p)
                    c.restore()
                }
                8 -> {
                    c.save(); c.rotate(if (it.vx < 0) -20f else 20f, it.x, it.y)
                    c.drawRoundRect(it.x - 5f, it.y - 25f, it.x + 5f, it.y + 20f, 4f, 4f, p)
                    p.color = Color.WHITE; c.drawRect(it.x - 1f, it.y - 19f, it.x + 1f, it.y + 12f, p)
                    p.color = Color.rgb(255, 220, 90); c.drawRect(it.x - 9f, it.y + 15f, it.x + 9f, it.y + 20f, p)
                    c.restore()
                }
                9 -> {
                    c.drawCircle(it.x, it.y, 11f, p); p.color = Color.YELLOW; c.drawCircle(it.x, it.y + 8f, 5f, p)
                    p.color = Color.rgb(255, 100, 25)
                }
                10 -> {
                    val shard = Path().apply { moveTo(it.x, it.y - 15f); lineTo(it.x + 8f, it.y); lineTo(it.x, it.y + 15f); lineTo(it.x - 8f, it.y); close() }
                    c.drawPath(shard, p); p.color = Color.WHITE; c.drawCircle(it.x, it.y, 3f, p); p.color = Color.rgb(100, 220, 255)
                }
                11 -> {
                    c.save(); c.rotate(if (it.vx < 0) -18f else 18f, it.x, it.y)
                    c.drawRoundRect(it.x - 9f, it.y - 23f, it.x + 9f, it.y + 22f, 9f, 9f, p)
                    p.color = Color.WHITE; c.drawCircle(it.x, it.y, 4f, p); c.restore(); p.color = Color.rgb(190, 90, 255)
                }
                5 -> c.drawCircle(it.x, it.y, 6f, p)
                else -> c.drawCircle(it.x, it.y, if (wIdx == 4) 6f else 8f, p)
            }
        }
        enemies.forEach {
            p.color = when (campaignStage) {
                1 -> when { it.hp >= 4 -> Color.rgb(170, 0, 200); it.hp == 3 -> Color.rgb(255, 90, 0); else -> Color.RED }
                2 -> when { it.hp >= 4 -> Color.rgb(255, 60, 20); it.hp == 3 -> Color.rgb(255, 150, 20); else -> Color.rgb(220, 55, 35) }
                3 -> when { it.hp >= 4 -> Color.rgb(205, 60, 255); it.hp == 3 -> Color.rgb(80, 140, 255); else -> Color.rgb(255, 70, 160) }
                else -> when { it.hp >= 4 -> Color.rgb(170, 0, 200); it.hp == 3 -> Color.rgb(255, 90, 0); else -> Color.RED }
            }
            c.drawRect(it.x - 35, it.y - 35, it.x + 35, it.y + 35, p)
        }
        eBullets.forEach {
            val special = it.effect != 0
            val coreColor = when (it.effect) { 1 -> Color.CYAN; 2 -> Color.rgb(210, 70, 255); else -> Color.rgb(255, 80, 80) }
            if (special) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = coreColor
                c.drawCircle(it.x, it.y, 17f, p); p.style = Paint.Style.FILL
            }
            p.color = coreColor; c.drawCircle(it.x, it.y, 11f, p)
            p.color = Color.WHITE; c.drawCircle(it.x, it.y, 5f, p)
        }
        boss?.let { b ->
            val now = System.currentTimeMillis()
            val hitGlow = now < bossHitFlashUntil
            val firing = now < bossShotFlashUntil
            val entrance = ((now - b.bornAt).coerceIn(0L, 1100L) / 1100f)
            val easedEntrance = entrance * entrance * (3f - 2f * entrance)
            val introPulse = if (entrance < 1f) (1f - entrance) else 0f
            val bob = kotlin.math.sin(now / 210.0).toFloat() * 7f
            val recoil = if (firing) 14f else 0f
            if (introPulse > 0f) {
                p.style = Paint.Style.STROKE; p.color = Color.rgb(255, 50, 50); p.strokeWidth = 7f
                val radius = 95f + (1f - introPulse) * 145f
                p.alpha = (introPulse * 210).toInt().coerceIn(0, 210)
                c.drawCircle(b.x, b.y + bob, radius, p)
                p.strokeWidth = 3f; c.drawCircle(b.x, b.y + bob, radius * .68f, p)
                p.style = Paint.Style.FILL; p.alpha = 255
                p.color = Color.rgb(110, 0, 20); p.alpha = (introPulse * 35).toInt()
                c.drawRect(0f, 0f, c.width.toFloat(), c.height.toFloat(), p); p.alpha = 255
            }
            if (hitGlow) {
                p.style = Paint.Style.STROKE; p.strokeWidth = 9f; p.color = Color.CYAN
                c.drawRoundRect(b.x - 130f, b.y + bob - 80f, b.x + 130f, b.y + bob + 80f, 28f, 28f, p)
                p.style = Paint.Style.FILL
            }
            c.save()
            c.translate(b.x, b.y + bob)
            c.scale(.72f + .28f * easedEntrance, .72f + .28f * easedEntrance)
            val wingMotion = kotlin.math.sin(now / 95.0).toFloat() * 12f
            p.color = if (hurt > 0 || hitGlow) Color.WHITE else Color.rgb(80, 10, 35)
            c.save(); c.rotate(wingMotion, -120f, 0f); c.drawRect(-150f, -32f, -112f, 48f, p); c.restore()
            c.save(); c.rotate(-wingMotion, 120f, 0f); c.drawRect(112f, -32f, 150f, 48f, p); c.restore()
            p.color = if (hurt > 0 || hitGlow) Color.WHITE else Color.rgb(120 + 20 * (b.num % 6), 20, 60)
            if (hurt > 0) hurt--
            c.drawRoundRect(-120f, -70f, 120f, 70f - recoil, 20f, 20f, p)
            p.color = Color.rgb(65, 15, 30); c.drawRect(-72f, 38f - recoil, 72f, 63f - recoil, p)
            p.color = Color.BLACK; c.drawRoundRect(-90f, -30f, -50f, 5f, 12f, 12f, p); c.drawRoundRect(50f, -30f, 90f, 5f, 12f, 12f, p)
            val eyeGlow = (150 + 100 * (0.5 + 0.5 * kotlin.math.sin(now / 100.0))).toInt()
            p.color = Color.rgb(255, eyeGlow, 30); c.drawCircle(-70f, -12f, 10f, p); c.drawCircle(70f, -12f, 10f, p)
            p.color = Color.rgb(60, 60, 60); c.drawRect(-60f, 70f - recoil, -40f, 95f - recoil, p); c.drawRect(40f, 70f - recoil, 60f, 95f - recoil, p)
            p.color = Color.rgb(255, 110, 15)
            c.drawCircle(-50f, 92f - recoil, 5f + 3f * kotlin.math.abs(kotlin.math.sin(now / 65.0)).toFloat(), p)
            c.drawCircle(50f, 92f - recoil, 5f + 3f * kotlin.math.abs(kotlin.math.sin(now / 65.0)).toFloat(), p)
            if (firing) {
                val pulse = ((bossShotFlashUntil - now).coerceIn(0L, 190L) / 190f)
                p.color = Color.YELLOW
                c.drawCircle(-50f, 100f - recoil, 12f + pulse * 18f, p)
                c.drawCircle(50f, 100f - recoil, 12f + pulse * 18f, p)
                p.color = Color.rgb(255, 90, 35)
                c.drawCircle(-50f, 100f - recoil, 6f + pulse * 9f, p)
                c.drawCircle(50f, 100f - recoil, 6f + pulse * 9f, p)
            }
            c.restore()
            p.color = Color.DKGRAY; c.drawRect(60f, 120f, c.width - 60f, 145f, p)
            p.color = Color.rgb(230, 40, 40); c.drawRect(60f, 120f, 60f + (c.width - 120f) * b.hp / b.maxHp, 145f, p)
        }
        parts.forEach { p.color = it.color; p.alpha = (it.life * 255 / 32).coerceIn(0, 255); c.drawCircle(it.x, it.y, 6f, p) }
        p.alpha = 255
        p.color = Color.WHITE; p.textSize = 52f
        if (campaignStage in 1..3) {
            p.textSize = 34f; p.color = Color.WHITE
            c.drawText("FASE $campaignStage • ${CampaignStages.name(campaignStage)}", 30f, 82f, p)
            c.drawText("Enemigos: ${enemiesDefeated.coerceAtMost(300)}/300", 30f, 124f, p)
            c.drawText("Puntos: $score  Vidas: $lives", 30f, 166f, p)
        } else {
            p.textSize = 52f; p.color = Color.WHITE
            c.drawText("Nivel ${level()}  Puntos: $score  Vidas: $lives", 30f, 90f, p)
        }
        if (activeMs < shieldUntil) {
            p.color = Color.CYAN; p.textSize = 36f
            c.drawText("ESCUDO ${((shieldUntil - activeMs + 999) / 1000)}s", 30f, 140f, p)
        }
        val wallNow = System.currentTimeMillis()
        if (wallNow < noMoveUntil || wallNow < noFireUntil) {
            val movingLeft = noMoveUntil > wallNow
            val until = if (movingLeft) noMoveUntil else noFireUntil
            val label = if (movingLeft) "INMOVILIZADO" else "DISPARO BLOQUEADO"
            p.color = if (movingLeft) Color.CYAN else Color.rgb(220, 100, 255)
            p.textSize = 38f; p.textAlign = Paint.Align.CENTER
            c.drawText("$label  ${((until - wallNow + 999) / 1000)}s", c.width / 2f, 200f, p)
            p.textAlign = Paint.Align.LEFT
        }
        if (activeMs < powerMessageUntil) {
            p.color = Color.YELLOW; p.textSize = 46f; p.textAlign = Paint.Align.CENTER
            c.drawText(powerMessage, c.width / 2f, c.height / 2.5f, p)
            p.textAlign = Paint.Align.LEFT
        }
        if (flash > 0) { flash--; p.color = Color.YELLOW; p.textSize = 80f; c.drawText("¡NIVEL ${level()}!", c.width / 2f - 200f, c.height / 3f, p); p.textSize = 52f }
        if (bossFlash > 0) { bossFlash--; p.color = Color.RED; p.textSize = 90f; c.drawText("¡JEFE!", c.width / 2f - 150f, c.height / 3f + 100f, p); p.textSize = 52f }
        if (campaignResult.isNotBlank()) {
            val resultLines = campaignResult.split('|')
            p.color = Color.YELLOW; p.textSize = 42f; p.textAlign = Paint.Align.CENTER
            resultLines.forEachIndexed { i, line -> c.drawText(line, c.width / 2f, c.height / 2f + i * 58f, p) }
            p.textAlign = Paint.Align.LEFT
        }
        if (lives <= 0) {
            c.drawText("GAME OVER  (+${if (dblCoins) score * 2 else score} monedas)", 40f, c.height / 2f, p)
            c.drawText("Tocá o pulsá X para reiniciar / Atrás: menú", 40f, c.height / 2f + 70f, p)
        }
        c.save()
        p.color = Color.rgb(100, 220, 255); p.alpha = 150; p.textSize = 28f; p.textAlign = Paint.Align.CENTER
        c.rotate(-90f, c.width - 20f, c.height / 2f)
        c.drawText("@tobi", c.width - 20f, c.height / 2f, p)
        c.restore()
        p.alpha = 255; p.textAlign = Paint.Align.LEFT
    }
}
