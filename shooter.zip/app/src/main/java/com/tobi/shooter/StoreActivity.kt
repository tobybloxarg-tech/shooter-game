package com.tobi.shooter

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class StoreActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var coinsView: TextView
    private lateinit var mode: String

    class Up(val key: String, val name: String, val base: Int, val max: Int, val desc: String)
    private val ups = listOf(
        Up("fire", "Cadencia", 50, 5, "Dispara más rápido"),
        Up("dmg", "Daño", 80, 4, "Cada bala hace más daño"),
        Up("life", "Vidas extra", 100, 3, "+1 vida al empezar"),
        Up("emp", "Habilidad: Pulso EMP", 350, 3, "Desbloquea el botón EMP: limpia disparos enemigos y daña a todos los enemigos y jefes. Recarga y daño mejoran por nivel."),
        Up("shieldSkill", "Habilidad: Escudo activo", 300, 3, "Desbloquea un escudo de emergencia. Cada nivel aumenta su duración y reduce su recarga."),
        Up("coinBonus", "Recompensa de batalla", 200, 5, "+10% monedas por los puntos de cada partida, por nivel")
    )
    private val skinNames = listOf("Cian", "Verde", "Naranja", "Rosa", "Dorado")
    private val skinPrices = listOf(0, 100, 200, 400, 800)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        mode = intent.getStringExtra("mode") ?: "upgrades"
        val root = Ui.root(this)
        Ui.add(root, Ui.title(this, if (mode == "shop") "TIENDA" else "MEJORAS"))
        coinsView = Ui.text(this, ""); Ui.add(root, coinsView)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.add(root, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(root)
    }
    override fun onResume() { super.onResume(); Audio.start(this); refresh() }
    override fun onPause() { super.onPause(); Audio.stopSoon() }

    private fun refresh() {
        coinsView.text = "Monedas: ${Save.coins(this)}"
        list.removeAllViews()
        if (mode == "upgrades") {
            Ui.add(list, Ui.text(this, "— ARMAS —"))
            for (i in Weapons.list.indices) {
                val w = Weapons.list[i]; val owned = Save.wOwned(this, i); val sel = Save.weapon(this) == i
                val label = when { sel -> "${w.name}  ✔ equipada\n${w.desc}"; owned -> "${w.name}  (equipar)\n${w.desc}"; else -> "${w.name}  —  ${w.price} monedas\n${w.desc}" }
                Ui.add(list, Ui.button(this, label, Color.rgb(150, 60, 40)) {
                    if (owned) Save.setWeapon(this, i)
                    else if (Save.coins(this) >= w.price) { Save.addCoins(this, -w.price); Save.setWOwned(this, i); Save.setWeapon(this, i) }
                    refresh()
                })
            }
            Ui.add(list, Ui.text(this, "— MEJORAS —"))
        }
        if (mode == "upgrades") for (u in ups) {
            if (u.key == "emp") Ui.add(list, Ui.text(this, "— HABILIDADES —"))
            if (u.key == "coinBonus") Ui.add(list, Ui.text(this, "— MÁS MEJORAS —"))
            val lv = Save.lvl(this, u.key)
            val cost = u.base * (lv + 1)
            val label = if (lv >= u.max) "${u.name}  (MAX)\n${u.desc}" else "${u.name}  nivel $lv/${u.max}\n${u.desc}  —  $cost monedas"
            Ui.add(list, Ui.button(this, label) {
                if (lv < u.max && Save.coins(this) >= cost) {
                    Save.addCoins(this, -cost); Save.setLvl(this, u.key, lv + 1); refresh()
                }
            }.also { it.isEnabled = lv < u.max && Save.coins(this) >= cost })
        } else for (i in skinNames.indices) {
            val owned = Save.owned(this, i)
            val sel = Save.skin(this) == i
            val label = when { sel -> "Nave ${skinNames[i]}  ✔ en uso"; owned -> "Nave ${skinNames[i]}  (usar)"; else -> "Nave ${skinNames[i]}  —  ${skinPrices[i]} monedas" }
            Ui.add(list, Ui.button(this, label, Skins.color(i)) {
                if (owned) Save.setSkin(this, i)
                else if (Save.coins(this) >= skinPrices[i]) { Save.addCoins(this, -skinPrices[i]); Save.setOwned(this, i); Save.setSkin(this, i) }
                refresh()
            }.also { it.setTextColor(Color.BLACK) })
        }
    }
}

object Skins {
    fun color(i: Int) = intArrayOf(Color.CYAN, Color.GREEN, Color.rgb(255, 150, 0), Color.rgb(255, 105, 180), Color.rgb(255, 215, 0))[i.coerceIn(0, 4)]
}
