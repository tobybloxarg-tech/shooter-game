package com.tobi.shooter

import android.app.Activity
import android.os.Bundle
import java.io.File

class GameActivity : Activity() {
    private lateinit var view: GameView
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Audio.stopNow()
        val requestedBoss = intent.getIntExtra(EXTRA_BOSS_LEVEL, 0)
        val replayBossLevel = if (requestedBoss in 1..Save.maxBossDefeated(this)) requestedBoss else 0
        view = GameView(this, File(Save.dataDir(this), "config.json").readText(), replayBossLevel)
        setContentView(view)
    }
    override fun onPause() { super.onPause(); view.stop() }
    override fun onResume() { super.onResume(); view.start() }
    override fun onDestroy() { super.onDestroy(); view.release() }

    companion object {
        const val EXTRA_BOSS_LEVEL = "boss_level"
    }
}
