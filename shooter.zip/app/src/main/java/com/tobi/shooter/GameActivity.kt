package com.tobi.shooter

import android.app.Activity
import android.os.Bundle
import java.io.File

class GameActivity : Activity() {
    private lateinit var view: GameView
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Audio.stopNow()
        view = GameView(this, File(Save.dataDir(this), "config.json").readText())
        setContentView(view)
    }
    override fun onPause() { super.onPause(); view.stop() }
    override fun onResume() { super.onResume(); view.start() }
    override fun onDestroy() { super.onDestroy(); view.release() }
}
