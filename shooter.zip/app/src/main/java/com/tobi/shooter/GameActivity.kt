package com.tobi.shooter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast
import org.json.JSONObject
import java.io.File

class GameActivity : Activity() {
    private lateinit var view: GameView
    private var pauseDialog: AlertDialog? = null
    private var savedThisRun = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Audio.stopNow()
        val saved = if (intent.getBooleanExtra(EXTRA_LOAD_SAVED, false)) Save.savedGame(this) else null
        val validSaved = saved?.let {
            try { val j=JSONObject(it); j.optString("format")=="tobi-shooter-run" && j.optInt("version")==1 } catch (_:Exception) { false }
        } == true
        val savedJson = if (validSaved) saved else null
        val replayBossLevel = if (savedJson != null) {
            try { JSONObject(savedJson).optInt("replayBossLevel",0).coerceIn(0,Save.maxBossDefeated(this)) } catch (_:Exception) { 0 }
        } else {
            val requestedBoss = intent.getIntExtra(EXTRA_BOSS_LEVEL, 0)
            if (requestedBoss in 1..Save.maxBossDefeated(this)) requestedBoss else 0
        }
        view = GameView(this, File(Save.dataDir(this), "config.json").readText(), replayBossLevel, savedJson != null)
        if (savedJson != null) {
            if (view.restoreSavedState(savedJson)) Save.clearSavedGame(this)
            else { Toast.makeText(this, "No se pudo cargar esa partida guardada", Toast.LENGTH_LONG).show(); finish(); return }
        }
        setContentView(view)
    }

    override fun onBackPressed() {
        if (pauseDialog?.isShowing == true) {
            pauseDialog?.dismiss()
            return
        }
        showPauseMenu()
    }

    private fun showPauseMenu() {
        view.stop()
        val content = Ui.root(this)
        Ui.add(content, Ui.title(this, "PAUSA"))
        val dialog = AlertDialog.Builder(this).setView(content).create()
        Ui.add(content, Ui.button(this, "▶  REANUDAR", Color.rgb(30, 150, 80)) {
            dialog.dismiss(); pauseDialog = null; view.start()
        })
        Ui.add(content, Ui.button(this, "💾  GUARDAR PARTIDA", Color.rgb(35, 115, 170)) {
            if (!view.canSave()) {
                Toast.makeText(this, "No se puede guardar una partida terminada", Toast.LENGTH_SHORT).show()
            } else if (Save.hasSavedGame(this)) {
                AlertDialog.Builder(this).setTitle("¿Reemplazar partida guardada?")
                    .setMessage("Hay una sola ranura. Se reemplazará la partida anterior.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Reemplazar") { _, _ -> saveGame() }.show()
            } else saveGame()
        })
        Ui.add(content, Ui.button(this, "SALIR AL MENÚ", Color.rgb(160, 65, 55)) {
            dialog.dismiss(); pauseDialog = null
            if (!savedThisRun) view.settleEarnings()
            finish()
        })
        dialog.setOnCancelListener { pauseDialog = null; view.start() }
        dialog.setCancelable(true)
        pauseDialog = dialog
        dialog.show()
    }

    private fun saveGame() {
        val saved = try { Save.setSavedGame(this, view.exportSavedState()) } catch (_: Exception) { false }
        if (saved) savedThisRun = true
        Toast.makeText(this, if (saved) "Partida guardada. Encontrala en Partidas guardadas." else "No se pudo guardar la partida", Toast.LENGTH_LONG).show()
    }

    override fun onPause() { if (::view.isInitialized) view.stop(); super.onPause() }
    override fun onResume() { super.onResume(); if (::view.isInitialized && pauseDialog?.isShowing != true) view.start() }
    override fun onDestroy() { super.onDestroy(); if (::view.isInitialized) view.release() }

    companion object {
        const val EXTRA_BOSS_LEVEL = "boss_level"
        const val EXTRA_LOAD_SAVED = "load_saved_game"
    }
}
