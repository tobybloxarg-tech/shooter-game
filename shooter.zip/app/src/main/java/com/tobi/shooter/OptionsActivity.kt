package com.tobi.shooter

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.widget.ScrollView

class OptionsActivity : Activity() {
    private lateinit var m: Button
    private lateinit var f: Button

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = Ui.root(this)
        Ui.add(l, Ui.title(this, "OPCIONES"))
        m = Ui.button(this, "") { Save.setMusic(this, !Save.music(this)); Audio.start(this); upd() }
        f = Ui.button(this, "") { Save.setSfx(this, !Save.sfx(this)); upd() }
        Ui.add(l, m); Ui.add(l, f)
        Ui.add(l, Ui.button(this, "GUARDAR PARTIDA EN ARCHIVO") { createSaveFile() })
        Ui.add(l, Ui.button(this, "CARGAR PARTIDA DE ARCHIVO") { confirmLoadSave() })
        Ui.add(l, Ui.button(this, "BORRAR PROGRESO", Color.rgb(160, 40, 40)) { Save.reset(this); upd() })
        Ui.add(l, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(l) }); upd()
    }

    private fun createSaveFile() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "tobi-shooter-partida.json")
        }
        startActivityForResult(intent, REQUEST_SAVE)
    }

    private fun confirmLoadSave() {
        AlertDialog.Builder(this)
            .setTitle("Cargar partida")
            .setMessage("La partida del archivo reemplazará el progreso actual del juego. ¿Querés continuar?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Elegir archivo") { _, _ ->
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, REQUEST_LOAD)
            }
            .show()
    }

    @Deprecated("Uses platform activity result API for compatibility with the existing project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            when (requestCode) {
                REQUEST_SAVE -> {
                    contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                        it.write(Save.exportBackup(this))
                    } ?: throw IllegalStateException("No se pudo abrir el archivo")
                    Toast.makeText(this, "Partida guardada en el archivo", Toast.LENGTH_LONG).show()
                }
                REQUEST_LOAD -> {
                    val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalStateException("No se pudo leer el archivo")
                    if (Save.importBackup(this, json)) {
                        upd()
                        Audio.start(this)
                        Toast.makeText(this, "Partida cargada", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "Ese archivo no es una partida válida de este juego", Toast.LENGTH_LONG).show()
                    }
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo procesar el archivo", Toast.LENGTH_LONG).show()
        }
    }

    private fun upd() {
        m.text = "Música: " + if (Save.music(this)) "SÍ" else "NO"
        f.text = "Efectos de sonido: " + if (Save.sfx(this)) "SÍ" else "NO"
    }
    override fun onResume() { super.onResume(); Audio.start(this) }
    override fun onPause() { super.onPause(); Audio.stopSoon() }

    companion object {
        private const val REQUEST_SAVE = 401
        private const val REQUEST_LOAD = 402
    }
}
