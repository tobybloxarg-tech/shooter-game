package com.tobi.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class LauncherActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var downloadButton: Button
    private lateinit var playButton: Button
    private val files = setOf("config.json", "shoot.wav", "explosion.wav", "music_menu.wav")
    private fun installed() = files.all { File(Save.dataDir(this), it).isFile }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(15, 15, 30)); setPadding(60, 60, 60, 60)
        }
        Ui.add(layout, Ui.title(this, "SHOOTER", 36f))
        status = Ui.text(this, ""); Ui.add(layout, status)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
        }
        Ui.add(layout, bar)
        downloadButton = Ui.button(this, "DESCARGAR ARCHIVOS") { download() }
        playButton = Ui.button(this, "JUGAR", Color.rgb(30, 160, 80)) {
            if (installed()) startActivity(Intent(this, MenuActivity::class.java))
        }
        Ui.add(layout, downloadButton); Ui.add(layout, playButton)
        setContentView(layout); refresh()
    }

    private fun refresh() {
        val ready = installed()
        status.text = if (ready) "Archivos del juego listos" else "Faltan los archivos del juego. Descargalos para poder jugar."
        downloadButton.text = if (ready) "VOLVER A DESCARGAR ARCHIVOS" else "DESCARGAR ARCHIVOS"
        playButton.isEnabled = ready
    }

    private fun download() {
        downloadButton.isEnabled = false; playButton.isEnabled = false
        bar.progress = 0; bar.isIndeterminate = true; bar.visibility = View.VISIBLE
        status.text = "Descargando archivos…"
        Thread {
            val temp = File(cacheDir, "downloaded-gamedata")
            try {
                temp.deleteRecursively(); check(temp.mkdirs())
                val connection = URL("https://github.com/tobybloxarg-tech/shooter-game/releases/download/latest-build/gamedata.zip").openConnection() as HttpURLConnection
                connection.connectTimeout = 15000; connection.readTimeout = 30000
                connection.instanceFollowRedirects = true
                try {
                    check(connection.responseCode == 200) { "Descarga no disponible" }
                    val archive = File(temp, "gamedata.zip")
                    connection.inputStream.use { input -> archive.outputStream().use { output ->
                        val buffer = ByteArray(8192); var total = 0L
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            total += count
                            check(total <= 10L * 1024 * 1024) { "Archivo demasiado grande" }
                            output.write(buffer, 0, count)
                        }
                    } }
                    val unpack = File(temp, "data").apply { mkdirs() }
                    val seen = mutableSetOf<String>()
                    ZipInputStream(archive.inputStream().buffered()).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            val name = entry.name.removePrefix("./")
                            if (entry.isDirectory) continue
                            check(name in files && seen.add(name)) { "Archivo de datos inválido" }
                            File(unpack, name).outputStream().use { output ->
                                val buffer = ByteArray(8192); var total = 0L
                                while (true) {
                                    val count = zip.read(buffer)
                                    if (count < 0) break
                                    total += count
                                    check(total <= 10L * 1024 * 1024) { "Archivo demasiado grande" }
                                    output.write(buffer, 0, count)
                                }
                            }
                            zip.closeEntry()
                        }
                    }
                    check(seen == files) { "Faltan archivos" }
                    org.json.JSONObject(File(unpack, "config.json").readText())
                    val dest = Save.dataDir(this).apply { mkdirs() }
                    for (name in files) File(unpack, name).copyTo(File(dest, name), overwrite = true)
                } finally { connection.disconnect() }
                runOnUiThread { if (!isFinishing && !isDestroyed) { bar.visibility = View.GONE; downloadButton.isEnabled = true; refresh() } }
            } catch (_: Exception) {
                runOnUiThread { if (!isFinishing && !isDestroyed) {
                    bar.visibility = View.GONE; downloadButton.isEnabled = true; refresh()
                    status.text = "No se pudieron descargar los archivos. Revisá tu conexión y reintentá."
                } }
            } finally { temp.deleteRecursively() }
        }.start()
    }
}
