package com.tobi.shooter

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import java.io.File

class LauncherActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val ver = 1
        val dir = Save.dataDir(this)
        val mark = File(dir, ".v$ver")
        if (!mark.exists()) {
            dir.deleteRecursively(); dir.mkdirs()
            for (name in assets.list("gamedata") ?: emptyArray()) {
                assets.open("gamedata/$name").use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
            }
            mark.writeText("ok")
        }
        startActivity(Intent(this, MenuActivity::class.java))
        finish()
    }
}
