package com.tobi.shooter

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.view.MotionEvent
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread
import kotlin.math.abs

private const val LAN_DISCOVERY_PORT = 37654
private const val LAN_GAME_PORT = 37655
private const val LAN_MAX_PLAYERS = 3

private data class LanRoom(val name: String, val address: String, val port: Int, val count: Int, val max: Int)
private data class LanPlayer(var id: String, var name: String, var x: Float = .5f, var lives: Int = 3, var score: Int = 0, var lastShot: Long = 0L)
private data class LanEnemy(val id: Int, var x: Float, var y: Float, var hp: Int = 1)
private data class LanBullet(var owner: String, var x: Float, var y: Float)

/** LAN lobby and room discovery. Gameplay is a host-authoritative shared co-op session. */
class LanMultiplayerActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var roomList: LinearLayout
    private lateinit var status: TextView
    private lateinit var roomInfo: TextView
    private val rooms = ConcurrentHashMap<String, LanRoom>()
    private var discovery: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var server: LanRoomServer? = null
    private var client: LanRoomClient? = null
    @Volatile private var active = true
    private val myId = UUID.randomUUID().toString()
    private val localName: String get() = Save.playerName(this).ifBlank { "Jugador" }

    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        multicastLock = wifi?.createMulticastLock("tobi-shooter-lan")?.apply { setReferenceCounted(false); acquire() }
        val root = Ui.root(this)
        Ui.add(root, Ui.title(this, "MULTIJUGADOR • WI-FI"))
        status = Ui.text(this, "Las personas deben estar conectadas a la misma red Wi-Fi.")
        Ui.add(root, status)
        roomInfo = Ui.text(this, "Tu nombre: $localName")
        Ui.add(root, roomInfo)
        Ui.add(root, Ui.button(this, "CREAR SALA", Color.rgb(35, 140, 90)) { createDialog() })
        Ui.add(root, Ui.button(this, "UNIRSE A SALA", Color.rgb(35, 115, 170)) { joinDialog() })
        Ui.add(root, Ui.button(this, "BUSCAR SALAS", Color.rgb(100, 85, 160)) { scan() })
        roomList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(roomList) }, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.add(root, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(root)
        beginDiscovery(); scan(); handler.post(refresh)
    }

    private fun createDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 8, 36, 0) }
        val name = EditText(this).apply { hint = "Nombre de la sala"; filters = arrayOf(InputFilter.LengthFilter(24)); setSingleLine(true) }
        val password = EditText(this).apply { hint = "Contraseña de sala"; filters = arrayOf(InputFilter.LengthFilter(32)); setSingleLine(true) }
        val max = Spinner(this).apply { adapter = ArrayAdapter(this@LanMultiplayerActivity, android.R.layout.simple_spinner_dropdown_item, listOf("2 jugadores", "3 jugadores")); setSelection(1) }
        box.addView(name); box.addView(password); box.addView(max)
        AlertDialog.Builder(this).setTitle("Crear sala")
            .setMessage("Solo en la misma Wi-Fi. La contraseña viaja por la red local sin cifrado: no reutilices una contraseña importante.")
            .setView(box).setNegativeButton("Cancelar", null).setPositiveButton("Crear", null).create().also { d ->
                d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val n = name.text.toString().trim(); val p = password.text.toString()
                    if (n.isBlank()) { name.error = "Escribí el nombre de la sala"; return@setOnClickListener }
                    if (p.isBlank()) { password.error = "Escribí una contraseña"; return@setOnClickListener }
                    val slots = if (max.selectedItemPosition == 0) 2 else 3
                    d.dismiss(); host(n, p, slots)
                } }
                d.show()
            }
    }

    private fun joinDialog(room: LanRoom? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 8, 36, 0) }
        val name = EditText(this).apply { hint = "Nombre de la sala"; setSingleLine(true); room?.let { setText(it.name) } }
        val password = EditText(this).apply { hint = "Contraseña"; setSingleLine(true) }
        box.addView(name); box.addView(password)
        AlertDialog.Builder(this).setTitle("Unirse a sala")
            .setMessage("Elegí una sala de la lista o escribí su nombre. Ambas personas deben usar la misma Wi-Fi.")
            .setView(box).setNegativeButton("Cancelar", null).setPositiveButton("Unirse", null).create().also { d ->
                d.setOnShowListener { d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val n = name.text.toString().trim(); val p = password.text.toString()
                    if (n.isBlank()) { name.error = "Escribí el nombre de sala"; return@setOnClickListener }
                    if (p.isBlank()) { password.error = "Escribí la contraseña"; return@setOnClickListener }
                    val r = rooms.values.firstOrNull { it.name.equals(n, true) }
                    if (r == null) { name.error = "No está en la lista; tocá Buscar salas"; return@setOnClickListener }
                    d.dismiss(); join(r, p)
                } }
                d.show()
            }
    }

    private fun host(name: String, pass: String, max: Int) {
        if (server != null || client != null) return
        status.text = "Abriendo sala en esta Wi-Fi…"
        thread(name = "lan-host-open") {
            try {
                val s = LanRoomServer(name, pass, max, localName, myId) { msg ->
                    runOnUiThread {
                        if (!active) return@runOnUiThread
                        when (msg.optString("type")) {
                            "players" -> { roomInfo.text = "Sala: $name · ${msg.optInt("count")}/$max jugadores"; status.text = msg.optJSONArray("names")?.let { jsonStrings(it).joinToString(" · ") } ?: "Sala lista" }
                            "start" -> launchGame(true, null)
                        }
                    }
                }
                server = s; LanSession.server = s; s.start()
                runOnUiThread {
                    if (!active) return@runOnUiThread
                    status.text = "Sala abierta. Esperá a tus amigos en la misma Wi-Fi."
                    roomInfo.text = "Sala: $name · 1/$max jugadores"
                    refreshRooms()
                }
            } catch (e: Exception) { runOnUiThread { status.text = e.message ?: "No se pudo crear la sala. Revisá tu Wi-Fi." } }
        }
    }

    private fun join(room: LanRoom, pass: String) {
        if (server != null || client != null) return
        status.text = "Conectando con ${room.name}…"
        thread(name = "lan-client-connect") {
            try {
                val c = LanRoomClient(room, pass, localName, UUID.randomUUID().toString()) { msg ->
                    runOnUiThread {
                        if (!active) return@runOnUiThread
                        when (msg.optString("type")) {
                            "players" -> { status.text = msg.optJSONArray("names")?.let { jsonStrings(it).joinToString(" · ") } ?: "En sala"; roomInfo.text = "Sala: ${room.name} · ${msg.optInt("count")}/${room.max} jugadores" }
                            "start" -> launchGame(false, cHolder)
                            "state" -> LanSession.onGameState?.invoke(msg)
                            "state" -> LanSession.onGameState?.invoke(msg)
                            "error" -> status.text = msg.optString("message", "No se pudo entrar")
                        }
                    }
                }
                cHolder = c
                client = c; LanSession.client = c; c.connect()
                runOnUiThread { if (active) { status.text = "Conectado a ${room.name}. Esperando que el anfitrión inicie…"; roomInfo.text = "Sala: ${room.name} · máximo ${room.max} jugadores" } }
            } catch (e: Exception) { runOnUiThread { if (active) status.text = e.message ?: "No se pudo conectar. Revisá la sala, la contraseña y el Wi-Fi." } }
        }
    }
    @Volatile private var cHolder: LanRoomClient? = null

    private fun launchGame(isHost: Boolean, connectedClient: LanRoomClient?) {
        if (isFinishing || isDestroyed) return
        val i = Intent(this, LanGameActivity::class.java).putExtra("host", isHost)
        if (isHost) i.putExtra("localId", myId)
        startActivity(i)
    }

    private fun beginDiscovery() {
        thread(name = "lan-discovery") {
            try {
                val s = DatagramSocket(null).apply { reuseAddress = true; broadcast = true; bind(java.net.InetSocketAddress(LAN_DISCOVERY_PORT)) }; discovery = s
                val buf = ByteArray(2048)
                while (active) {
                    val packet = DatagramPacket(buf, buf.size); s.receive(packet)
                    val msg = try { JSONObject(String(packet.data, packet.offset, packet.length, Charsets.UTF_8)) } catch (_: Exception) { continue }
                    if (msg.optString("id") == myId) continue
                    val room = LanRoom(msg.optString("name"), packet.address.hostAddress ?: continue, msg.optInt("port"), msg.optInt("count"), msg.optInt("max"))
                    if (room.name.isNotBlank() && room.count < room.max) rooms[room.name.lowercase()] = room
                    runOnUiThread { if (active) refreshRooms() }
                }
            } catch (_: Exception) { if (active) runOnUiThread { status.text = "No se pudo buscar en la red local." } }
        }
    }

    private fun scan() {
        rooms.clear(); status.text = "Buscando salas en la misma Wi-Fi…"; refreshRooms()
        thread { try { Thread.sleep(1300) } catch (_: Exception) {}; runOnUiThread { if (active && server == null && client == null) status.text = if (rooms.isEmpty()) "No encontré salas: verificá que estén en la misma Wi-Fi." else "Elegí una sala de la lista para unirte."; refreshRooms() } }
    }

    private val refresh = object : Runnable { override fun run() { if (!active) return; server?.announce(); refreshRooms(); handler.postDelayed(this, 1000) } }
    private fun refreshRooms() {
        if (!::roomList.isInitialized) return
        roomList.removeAllViews()
        rooms.values.sortedBy { it.name.lowercase() }.forEach { r ->
            Ui.add(roomList, Ui.button(this, "${r.name}  ·  ${r.count}/${r.max} jugadores\nTocá para ingresar") { joinDialog(r) })
        }
        server?.let { s ->
            Ui.add(roomList, Ui.text(this, "Jugadores: ${s.names().joinToString(", ")}"))
            Ui.add(roomList, Ui.button(this, "INICIAR PARTIDA", Color.rgb(30, 150, 80)) { s.startGame() }.also { it.isEnabled = s.names().size >= 2 })
            Ui.add(roomList, Ui.button(this, "CERRAR SALA", Color.rgb(170, 60, 50)) { s.close(); server = null; status.text = "Sala cerrada."; roomInfo.text = "Tu nombre: $localName"; refreshRooms() })
        }
        if (client != null) Ui.add(roomList, Ui.button(this, "SALIR DE LA SALA", Color.rgb(170, 60, 50)) { client?.close(); client = null; cHolder = null; roomInfo.text = "Tu nombre: $localName"; status.text = "Saliste de la sala."; refreshRooms() })
    }

    private fun jsonStrings(a: JSONArray) = (0 until a.length()).map { a.optString(it) }
    override fun onDestroy() {
        active = false; handler.removeCallbacksAndMessages(null)
        try { discovery?.close() } catch (_: Exception) {}
        server?.close(); server = null; client?.close(); client = null
        try { multicastLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}

private class LanRoomServer(
    private val name: String, private val password: String, private val max: Int,
    hostName: String, private val hostId: String, private val onEvent: (JSONObject) -> Unit
) {
    private val socket = ServerSocket(LAN_GAME_PORT)
    private val players = ConcurrentHashMap<String, LanPlayer>()
    private val peers = ConcurrentHashMap<String, Socket>()
    private val writers = ConcurrentHashMap<String, PrintWriter>()
    private val enemies = ArrayList<LanEnemy>()
    private val bullets = ArrayList<LanBullet>()
    private var nextEnemy = 0
    private var nextSpawn = System.currentTimeMillis() + 1300
    @Volatile private var open = true
    @Volatile private var playing = false
    private val startedEvent = JSONObject().put("type", "start")
    init { players[hostId] = LanPlayer(hostId, hostName) }
    fun start() { thread(name = "lan-accept") { acceptLoop() } }
    fun names() = players.values.sortedBy { it.id }.map { it.name }
    fun announce() {
        if (!open || playing) return
        thread(name = "lan-room-beacon") {
            try {
                val data = JSONObject().put("id", hostId).put("name", name).put("port", socket.localPort).put("count", players.size).put("max", max).toString().toByteArray(Charsets.UTF_8)
                DatagramSocket().use { ds -> ds.broadcast = true; ds.send(DatagramPacket(data, data.size, InetAddress.getByName("255.255.255.255"), LAN_DISCOVERY_PORT)) }
            } catch (_: Exception) { }
        }
    }
    private fun event(type: String) {
        val names = JSONArray(); players.values.sortedBy { it.id }.forEach { names.put(it.name) }
        val m = JSONObject().put("type", type).put("count", players.size).put("names", names)
        onEvent(m)
        val line = m.toString()
        writers.values.toList().forEach { try { synchronized(it) { it.println(line) } } catch (_: Exception) {} }
    }
    private fun acceptLoop() {
        while (open) try {
            val s = socket.accept(); s.soTimeout = 6000
            thread(name = "lan-peer-auth") {
                var id = ""
                try {
                    val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                    val hello = JSONObject(reader.readLine() ?: "{}")
                    val candidate = hello.optString("name").trim().take(18)
                    val pass = hello.optString("password")
                    if (playing || pass != password || candidate.isBlank() || players.size >= max) {
                        PrintWriter(s.getOutputStream(), true).println(JSONObject().put("type", "error").put("message", when { pass != password -> "Contraseña incorrecta"; players.size >= max -> "La sala está llena"; else -> "La partida ya empezó" }))
                        s.close(); return@thread
                    }
                    id = hello.optString("id").ifBlank { UUID.randomUUID().toString() }
                    s.soTimeout = 0
                    val out = PrintWriter(s.getOutputStream(), true); writers[id] = out; peers[id] = s
                    players[id] = LanPlayer(id, candidate)
                    synchronized(out) { out.println(JSONObject().put("type", "joined").put("id", id).put("room", name).toString()) }
                    event("players")
                    while (open && !s.isClosed) {
                        val line = reader.readLine() ?: break
                        val msg = try { JSONObject(line) } catch (_: Exception) { continue }
                        if (msg.optString("type") == "input") players[id]?.x = msg.optDouble("x", .5).toFloat().coerceIn(.04f, .96f)
                    }
                } catch (_: Exception) { }
                finally {
                    try { s.close() } catch (_: Exception) {}
                    if (id.isNotBlank()) { peers.remove(id); writers.remove(id); players.remove(id); event("players") }
                }
            }
        } catch (_: SocketException) { break } catch (_: Exception) { if (!open) break }
    }
    fun startGame() {
        if (!open || playing || players.size < 2) return
        playing = true
        onEvent(startedEvent)
        writers.values.forEach { try { synchronized(it) { it.println(startedEvent.toString()) } } catch (_: Exception) {} }
        thread(name = "lan-game-loop") { gameLoop() }
    }
    private fun gameLoop() {
        var last = System.currentTimeMillis()
        while (open && playing) {
            val now = System.currentTimeMillis(); val dt = (now - last).coerceIn(1L, 100L); last = now
            synchronized(this) {
                if (now >= nextSpawn && enemies.size < 16) {
                    enemies.add(LanEnemy(++nextEnemy, .05f + Math.random().toFloat() * .9f, -.05f, 1 + (nextEnemy / 15)))
                    nextSpawn = now + (1000L - (nextEnemy / 4) * 35L).coerceAtLeast(320L)
                }
                players.values.forEach { player ->
                    if (player.lives > 0 && now - player.lastShot > 560L) { bullets.add(LanBullet(player.id, player.x, .82f)); player.lastShot = now }
                }
                enemies.forEach { it.y += .24f * dt / 1000f }
                bullets.forEach { it.y -= .78f * dt / 1000f }
                val bit = bullets.iterator()
                while (bit.hasNext()) {
                    val b = bit.next(); val target = enemies.firstOrNull { abs(it.x - b.x) < .055f && abs(it.y - b.y) < .045f }
                    if (target != null) { target.hp--; bit.remove(); if (target.hp <= 0) { enemies.remove(target); players[b.owner]?.score = (players[b.owner]?.score ?: 0) + 1 } }
                    else if (b.y < -.05f) bit.remove()
                }
                val eit = enemies.iterator()
                while (eit.hasNext()) { val e = eit.next(); if (e.y > .91f) { val victim = players.values.filter { it.lives > 0 }.minByOrNull { abs(it.x - e.x) }; if (victim != null) victim.lives = (victim.lives - 1).coerceAtLeast(0); eit.remove() } }
                broadcastState()
            }
            try { Thread.sleep(80) } catch (_: InterruptedException) { break }
        }
    }
    private fun broadcastState() {
        val p = JSONArray(); players.values.sortedBy { it.id }.forEach { p.put(JSONObject().put("id",it.id).put("name",it.name).put("x",it.x.toDouble()).put("lives",it.lives).put("score",it.score)) }
        val e = JSONArray(); enemies.forEach { e.put(JSONObject().put("x",it.x.toDouble()).put("y",it.y.toDouble()).put("hp",it.hp)) }
        val b = JSONArray(); bullets.forEach { b.put(JSONObject().put("owner",it.owner).put("x",it.x.toDouble()).put("y",it.y.toDouble())) }
        val line = JSONObject().put("type","state").put("players",p).put("enemies",e).put("bullets",b).put("level",1 + nextEnemy / 15).toString()
        writers.values.toList().forEach { try { synchronized(it) { it.println(line) } } catch (_: Exception) {} }
    }
    fun localInput(x: Float) { players[hostId]?.x = x.coerceIn(.04f,.96f) }
    @Synchronized fun currentState(): JSONObject {
        val p = JSONArray(); players.values.sortedBy { it.id }.forEach { p.put(JSONObject().put("id",it.id).put("name",it.name).put("x",it.x.toDouble()).put("lives",it.lives).put("score",it.score)) }
        val e = JSONArray(); enemies.forEach { e.put(JSONObject().put("x",it.x.toDouble()).put("y",it.y.toDouble()).put("hp",it.hp)) }
        val b = JSONArray(); bullets.forEach { b.put(JSONObject().put("owner",it.owner).put("x",it.x.toDouble()).put("y",it.y.toDouble())) }
        return JSONObject().put("players",p).put("enemies",e).put("bullets",b).put("level",1+nextEnemy/15)
    }
    fun close() { open = false; playing = false; try { socket.close() } catch (_: Exception) {}; peers.values.forEach { try { it.close() } catch (_: Exception) {} }; writers.clear(); peers.clear(); LanSession.server=null }
}

private class LanRoomClient(private val room: LanRoom, private val password: String, private val name: String, private val requestedId: String, private val onMessage: (JSONObject) -> Unit) {
    @Volatile private var open = true
    private var socket: Socket? = null
    private var writer: PrintWriter? = null
    @Volatile var playerId: String = ""
        private set
    fun connect() {
        val s = Socket(); s.connect(java.net.InetSocketAddress(room.address, room.port), 5000); s.soTimeout = 8000; socket = s
        val out = PrintWriter(s.getOutputStream(), true); writer = out
        synchronized(out) { out.println(JSONObject().put("name",name).put("password",password).put("id",requestedId).toString()) }
        val reader = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
        val first = JSONObject(reader.readLine() ?: throw Exception("El anfitrión no respondió"))
        if (first.optString("type") == "error") throw Exception(first.optString("message","No se pudo entrar"))
        if (first.optString("type") != "joined") throw Exception("Respuesta inesperada de la sala")
        playerId = first.optString("id"); s.soTimeout = 0
        thread(name = "lan-client-listener") {
            try { while (open) { val line = reader.readLine() ?: break; val m = try { JSONObject(line) } catch (_: Exception) { continue }; onMessage(m) } }
            catch (_: Exception) { }
            if (open) onMessage(JSONObject().put("type","error").put("message","Se perdió la conexión con el anfitrión."))
        }
    }
    fun input(x: Float) { val w = writer ?: return; try { synchronized(w) { w.println(JSONObject().put("type","input").put("x",x.toDouble()).toString()) } } catch (_: Exception) {} }
    fun close() { open = false; try { socket?.close() } catch (_: Exception) {}; LanSession.client=null }
}

class LanGameActivity : Activity() {
    private lateinit var gameView: LanGameView
    private val handler = Handler(Looper.getMainLooper())
    private var isHost = false
    private var server: LanRoomServer? = null
    private var client: LanRoomClient? = null
    private val states = LanGameState()
    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)
        isHost = intent.getBooleanExtra("host", false)
        server = if (isHost) LanSession.server else null
        client = if (!isHost) LanSession.client else null
        gameView = LanGameView(this, states) { x -> if (isHost) server?.localInput(x) else client?.input(x) }
        setContentView(gameView)
        if (!isHost && client == null) { finish(); return }
        if (!isHost) LanSession.onGameState = { msg -> runOnUiThread { states.update(msg); gameView.invalidate() } }
        handler.post(object : Runnable { override fun run() { if (isFinishing) return; if (isHost) { server?.let { states.update(it.currentState()) }; gameView.invalidate() }; handler.postDelayed(this, 100) } })
    }
    override fun onBackPressed() { AlertDialog.Builder(this).setTitle("Salir de la sala").setMessage("Vas a salir de la partida multijugador.").setNegativeButton("Seguir",null).setPositiveButton("Salir") { _,_ -> finish() }.show() }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); if (!isHost) { client?.close(); LanSession.client=null }; LanSession.onGameState=null; super.onDestroy() }
}

private class LanGameState {
    @Volatile var players: List<JSONObject> = emptyList()
    @Volatile var enemies: List<JSONObject> = emptyList()
    @Volatile var bullets: List<JSONObject> = emptyList()
    @Volatile var level: Int = 1
    fun update(j: JSONObject) { players=arr(j,"players"); enemies=arr(j,"enemies"); bullets=arr(j,"bullets"); level=j.optInt("level",1) }
    private fun arr(j:JSONObject,k:String)=(0 until (j.optJSONArray(k)?.length()?:0)).mapNotNull { j.optJSONArray(k)?.optJSONObject(it) }
}

private class LanGameView(context: Context, private val state: LanGameState, private val input: (Float)->Unit) : View(context) {
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    private val colors=intArrayOf(Color.CYAN,Color.GREEN,Color.YELLOW,Color.MAGENTA)
    override fun onDraw(c: Canvas) {
        super.onDraw(c); c.drawColor(Color.rgb(9,12,28)); val w=width.toFloat();val h=height.toFloat()
        p.color=Color.WHITE;p.textSize=32f;p.textAlign=Paint.Align.LEFT;c.drawText("CO-OP WI-FI  •  Nivel ${state.level}",24f,46f,p)
        state.players.forEachIndexed { i, j ->
            val x=j.optDouble("x",.5).toFloat()*w; val y=h*.87f
            p.color=colors[i%colors.size];c.drawRoundRect(x-24,y-30,x+24,y+20,8f,8f,p)
            p.color=Color.WHITE;p.textSize=20f;p.textAlign=Paint.Align.CENTER
            c.drawText("${j.optString("name")}  ♥${j.optInt("lives")}  ★${j.optInt("score")}",x,y+48,p)
        }
        p.textAlign=Paint.Align.LEFT
        state.enemies.forEach { j -> val x=j.optDouble("x",.5).toFloat()*w;val y=j.optDouble("y",.2).toFloat()*h;p.color=if(j.optInt("hp")>1) Color.MAGENTA else Color.RED;c.drawRect(x-19,y-18,x+19,y+18,p) }
        state.bullets.forEach { j -> p.color=colors[(state.players.indexOfFirst{it.optString("id")==j.optString("owner")}.coerceAtLeast(0))%colors.size];val x=j.optDouble("x",.5).toFloat()*w;val y=j.optDouble("y",.5).toFloat()*h;c.drawCircle(x,y,5f,p) }
        p.color=Color.LTGRAY;p.textSize=22f;p.textAlign=Paint.Align.CENTER;c.drawText("Deslizá para moverte · disparo automático",w/2,h-22,p)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean { when(e.action){MotionEvent.ACTION_DOWN,MotionEvent.ACTION_MOVE->{input((e.x/width.coerceAtLeast(1)).coerceIn(.04f,.96f));return true}};return true }
}

private object LanSession {
    @Volatile var server: LanRoomServer?=null
    @Volatile var client: LanRoomClient?=null
    @Volatile var onGameState: ((JSONObject)->Unit)?=null
}
