package com.tobi.shooter

object CampaignStages {
    const val COUNT = 3
    const val ENEMIES_PER_BOSS = 300
    fun name(stage: Int) = when (stage) { 1 -> "Órbita Azul"; 2 -> "Cinturón Volcánico"; 3 -> "Nebulosa Final"; else -> "Campaña" }
    fun description(stage: Int) = when (stage) {
        1 -> "Defendé la órbita y derrotá al guardián tras 300 enemigos."
        2 -> "Atravesá el cinturón volcánico y vencé a su jefe."
        3 -> "Llegá al núcleo de la nebulosa y derrotá al jefe final para terminar el juego."
        else -> ""
    }
}
