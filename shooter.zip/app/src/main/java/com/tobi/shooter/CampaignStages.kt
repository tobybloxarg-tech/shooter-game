package com.tobi.shooter

object CampaignStages {
    const val COUNT = 3
    const val ENEMIES_PER_BOSS = 300
    const val BOSSES_PER_STAGE = 5
    fun name(stage: Int) = when (stage) { 1 -> "Órbita Azul"; 2 -> "Cinturón Volcánico"; 3 -> "Nebulosa Final"; else -> "Campaña" }
    fun difficulty(stage: Int) = when (stage) { 1 -> "NORMAL"; 2 -> "DIFÍCIL"; 3 -> "EXTREMA"; else -> "" }
    fun description(stage: Int) = when (stage) {
        1 -> "Normal. Defendé la órbita: 5 jefes, uno cada 300 enemigos."
        2 -> "Difícil: enemigos más rápidos y resistentes; jefes con más vida y ataques más veloces."
        3 -> "Extrema: enemigos todavía más duros y jefes muy resistentes con ataques rápidos. Vencé los 5, incluido el final."
        else -> ""
    }
}
