package com.tobi.shooter

object CampaignStages {
    const val COUNT = 3
    const val ENEMIES_PER_BOSS = 300
    const val BOSSES_PER_STAGE = 5
    fun name(stage: Int) = when (stage) { 1 -> "Órbita Azul"; 2 -> "Cinturón Volcánico"; 3 -> "Nebulosa Final"; else -> "Campaña" }
    fun description(stage: Int) = when (stage) {
        1 -> "Defendé la órbita: vencé 5 jefes, uno cada 300 enemigos."
        2 -> "Atravesá el cinturón volcánico y vencé a sus 5 jefes."
        3 -> "Llegá al núcleo de la nebulosa: vencé 5 jefes, incluido el final, para terminar el juego."
        else -> ""
    }
}
