package com.tobi.shooter

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random

object Roulette {
    class Prize(val label: String, val name: String, val weight: Int, val color: Int)
    val prizes = listOf(
        Prize("50", "50 monedas", 30, Color.rgb(70, 130, 180)),
        Prize("150", "150 monedas", 25, Color.rgb(60, 160, 90)),
        Prize("400", "400 monedas", 12, Color.rgb(200, 150, 30)),
        Prize("+2 VIDAS", "+2 vidas extra durante 3 partidas", 12, Color.rgb(200, 60, 60)),
        Prize("x2", "Monedas dobles durante 3 partidas", 10, Color.rgb(140, 70, 190)),
        Prize("NAVE", "Una nave nueva al azar", 6, Color.rgb(230, 100, 160)),
        Prize("ARMA", "Un arma nueva al azar", 4, Color.rgb(230, 120, 30)),
        Prize("2000", "JACKPOT: 2000 monedas", 1, Color.rgb(255, 215, 0))
    )
    val skinNames = listOf("Cian", "Verde", "Naranja", "Rosa", "Dorado")
    fun pick(): Int {
        var r = Random.nextInt(prizes.sumOf { it.weight }); 
        for (i in prizes.indices) { r -= prizes[i].weight; if (r < 0) return i }
        return 0
    }
    fun claim(c: Context, i: Int): String {
        when (i) {
            0 -> Save.addCoins(c, 50); 1 -> Save.addCoins(c, 150); 2 -> Save.addCoins(c, 400); 7 -> Save.addCoins(c, 2000)
            3 -> Save.setBonusGames(c, Save.bonusGames(c) + 3)
            4 -> Save.setDblGames(c, Save.dblGames(c) + 3)
            5 -> {
                val free = (1..4).filter { !Save.owned(c, it) }
                if (free.isEmpty()) { Save.addCoins(c, 300); return "Ya tenías todas las naves: +300 monedas" }
                val k = free.random(); Save.setOwned(c, k); return "Nave ${skinNames[k]} desbloqueada (equipala en la Tienda)"
            }
            6 -> {
                val free = (1..11).filter { !Save.wOwned(c, it) }
                if (free.isEmpty()) { Save.addCoins(c, 500); return "Ya tenías todas las armas: +500 monedas" }
                val k = free.random(); Save.setWOwned(c, k); return "${Weapons.list[k].name} desbloqueada (equipala en Mejoras)"
            }
        }
        return prizes[i].name
    }
}

class WheelView(ctx: Context) : View(ctx) {
    var rot = 0f
    var pulse = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f - 30f
        val n = Roulette.prizes.size; val sweep = 360f / n
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        for (i in 0 until n) {
            val a = rot + i * sweep - 90f - sweep / 2f
            p.style = Paint.Style.FILL; p.color = Roulette.prizes[i].color; c.drawArc(rect, a, sweep, true, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; p.strokeWidth = 4f; c.drawArc(rect, a, sweep, true, p)
            p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textSize = 34f; p.textAlign = Paint.Align.CENTER
            c.save(); c.rotate(a + sweep / 2f, cx, cy); c.drawText(Roulette.prizes[i].label, cx + r * 0.62f, cy + 12f, p); c.restore()
        }
        p.style = Paint.Style.STROKE; p.color = Color.rgb(50, 220, 255); p.strokeWidth = 5f + pulse * 7f
        c.drawCircle(cx, cy, r + 8f, p)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(15, 15, 30); c.drawCircle(cx, cy, 39f, p)
        p.color = Color.rgb(50, 220, 255); c.drawCircle(cx, cy, 25f + pulse * 5f, p)
        p.color = Color.WHITE; c.drawCircle(cx, cy, 12f, p)
        val tipY = cy - r - 24f - pulse * 8f
        p.color = Color.WHITE; val t = Path(); t.moveTo(cx - 28f, tipY); t.lineTo(cx + 28f, tipY); t.lineTo(cx, cy - r + 36f); t.close(); c.drawPath(t, p)
    }
}

class RouletteActivity : Activity() {
    private lateinit var wheel: WheelView
    private lateinit var spin: Button
    private lateinit var claim: Button
    private lateinit var info: TextView
    private var spinning = false
    private var idleAnimator: ValueAnimator? = null
    private var spinPulseAnimator: ValueAnimator? = null
    private val timerHandler = Handler(Looper.getMainLooper())
    private var lastTimerCheckpoint = 0L
    private fun checkpointTimer() {
        val now = SystemClock.elapsedRealtime()
        if (lastTimerCheckpoint != 0L && now > lastTimerCheckpoint) Save.addPlayMs(this, now - lastTimerCheckpoint)
        lastTimerCheckpoint = now
    }
    private val timerTick = object : Runnable {
        override fun run() { checkpointTimer(); refresh(); timerHandler.postDelayed(this, 1000L) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = Ui.root(this)
        Ui.add(l, Ui.title(this, "RULETA"))
        wheel = WheelView(this)
        if (Save.pending(this) >= 0) wheel.rot = -Save.pending(this) * (360f / Roulette.prizes.size)
        wheel.minimumHeight = 800
        l.addView(wheel, android.widget.LinearLayout.LayoutParams(-1, 800))
        info = Ui.text(this, ""); Ui.add(l, info)
        spin = Ui.button(this, "GIRAR", Color.rgb(30, 160, 80)) { doSpin() }
        claim = Ui.button(this, "RECLAMAR", Color.rgb(200, 150, 30)) { doClaim() }
        Ui.add(l, spin); Ui.add(l, claim)
        val total = Roulette.prizes.sumOf { it.weight }
        Ui.add(l, Ui.text(this, Roulette.prizes.joinToString("\n") { "${it.name}: ${it.weight * 100 / total}%" }))
        Ui.add(l, Ui.button(this, "VOLVER", Color.rgb(90, 90, 110)) { finish() })
        setContentView(android.widget.ScrollView(this).apply { setBackgroundColor(Color.rgb(15, 15, 30)); isFillViewport = true; addView(l) })
        l.minimumHeight = resources.displayMetrics.heightPixels
        refresh()
    }
    override fun onResume() {
        super.onResume(); Audio.start(this); lastTimerCheckpoint = SystemClock.elapsedRealtime(); refresh()
        timerHandler.removeCallbacks(timerTick)
        timerHandler.post(timerTick)
    }
    override fun onPause() {
        timerHandler.removeCallbacks(timerTick); checkpointTimer(); lastTimerCheckpoint = 0L
        super.onPause(); stopIdleAnimation(); Audio.stopSoon()
    }

    private fun startIdleAnimation() {
        if (idleAnimator?.isRunning == true || spinning || Save.pending(this) >= 0) return
        idleAnimator = ValueAnimator.ofFloat(wheel.rot, wheel.rot + 360f).apply {
            duration = 30000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { wheel.rot = it.animatedValue as Float; wheel.invalidate() }
            start()
        }
    }

    private fun stopIdleAnimation() {
        idleAnimator?.cancel()
        idleAnimator = null
    }

    private fun startSpinPulse() {
        stopSpinPulse()
        spinPulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220L; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener { wheel.pulse = it.animatedValue as Float; wheel.invalidate() }
            start()
        }
    }

    private fun stopSpinPulse() {
        spinPulseAnimator?.cancel(); spinPulseAnimator = null
        if (::wheel.isInitialized) { wheel.pulse = 0f; wheel.invalidate() }
    }

    private fun refresh() {
        val pend = Save.pending(this)
        val played = Save.playMs(this).coerceAtMost(Save.NEED_MS)
        val ready = played >= Save.NEED_MS
        claim.visibility = if (pend >= 0 && !spinning) View.VISIBLE else View.GONE
        if (pend >= 0) claim.text = "RECLAMAR: " + Roulette.prizes[pend].name
        spin.isEnabled = ready && pend < 0 && !spinning
        info.text = when {
            spinning -> "¡Girando la ruleta!"
            pend >= 0 -> "¡Ganaste! Reclamá tu premio."
            ready -> "¡La ruleta está lista!"
            else -> {
                val remainingMs = (Save.NEED_MS - played).coerceAtLeast(0L)
                val left = (remainingMs + 999L) / 1000L
                "Faltan %02d:%02d para girar".format(left / 60, left % 60)
            }
        }
        if (pend < 0 && !spinning) startIdleAnimation() else stopIdleAnimation()
    }

    private fun doSpin() {
        if (spinning || Save.playMs(this) < Save.NEED_MS || Save.pending(this) >= 0) return
        val k = Roulette.pick()
        Save.resetPlayMs(this); Save.setPending(this, k)
        spinning = true; stopIdleAnimation(); spin.isEnabled = false; startSpinPulse()
        val startAngle = ((wheel.rot % 360f) + 360f) % 360f
        wheel.rot = startAngle
        val prizeAngle = ((-k * (360f / Roulette.prizes.size) + Random.nextInt(-14, 15)) + 360f) % 360f
        val delta = (prizeAngle - startAngle + 360f) % 360f
        val target = startAngle + 360f * 6 + delta
        ValueAnimator.ofFloat(startAngle, target).apply {
            duration = 5000; interpolator = DecelerateInterpolator(2f)
            addUpdateListener { wheel.rot = it.animatedValue as Float; wheel.invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { stopSpinPulse(); spinning = false; refresh() }
            })
            start()
        }
    }

    private fun doClaim() {
        val k = Save.pending(this); if (k < 0) return
        val msg = Roulette.claim(this, k)
        Save.setPending(this, -1); refresh()
        info.text = "Reclamado: $msg"
    }
}
