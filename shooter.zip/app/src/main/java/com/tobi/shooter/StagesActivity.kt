package com.tobi.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView

class StagesActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
    override fun onResume() {
        super.onResume()
        val root = Ui.root(this)
        Ui.add(root, Ui.title(this, "ELEGÍ UNA FASE"))
        Ui.add(root, Ui.text(this, "Cada fase tiene su propio mapa. Derrotá 300 enemigos para que aparezca su jefe y desbloquees la siguiente."))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val unlocked = Save.unlockedStage(this)
        for (stage in 1..CampaignStages.COUNT) {
            val isUnlocked = stage <= unlocked
            val label = if (isUnlocked) "FASE $stage • ${CampaignStages.name(stage)}\n${CampaignStages.description(stage)}\nTOCÁ PARA JUGAR" else "🔒 FASE $stage • ${CampaignStages.name(stage)}\nDerrotá al jefe de la fase anterior para desbloquear"
            Ui.add(list, Ui.button(this, label, if (isUnlocked) intArrayOf(Color.rgb(30,105,160),Color.rgb(170,75,25),Color.rgb(105,45,155))[stage-1] else Color.DKGRAY) {
                if (isUnlocked) startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_STAGE, stage))
            }.also { it.isEnabled = isUnlocked })
        }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        Ui.add(root, Ui.button(this, "VOLVER", Color.rgb(90,90,110)) { finish() })
        setContentView(root)
    }
}
