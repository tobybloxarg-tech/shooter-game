package com.tobi.shooter

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.io.File
import org.json.JSONObject

object Save {
    private fun p(c: Context) = c.getSharedPreferences("save", Context.MODE_PRIVATE)
    fun coins(c: Context) = p(c).getInt("coins", 0)
    fun addCoins(c: Context, n: Int) {
        val prefs = p(c)
        val next = (coins(c).toLong() + n).coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
        val record = maxOf(prefs.getInt("maxCoins", 0), coins(c), next)
        prefs.edit().putInt("coins", next).putInt("maxCoins", record).apply()
    }
    fun maxCoins(c: Context): Int {
        val prefs = p(c)
        val record = maxOf(prefs.getInt("maxCoins", 0), coins(c))
        if (record != prefs.getInt("maxCoins", 0)) prefs.edit().putInt("maxCoins", record).apply()
        return record
    }
    fun username(c: Context) = p(c).getString("username", "")?.trim().orEmpty()
    fun setUsername(c: Context, value: String) = p(c).edit().putString("username", value.trim().take(20)).apply()
    fun bossWins(c: Context) = maxOf(p(c).getInt("bossWins", 0), maxBossDefeated(c))
    fun recordBossWin(c: Context) {
        val next = (bossWins(c).toLong() + 1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        p(c).edit().putInt("bossWins", next).apply()
    }
    fun selectedTag(c: Context) = p(c).getString("selectedTag", "")?.orEmpty() ?: ""
    fun setSelectedTag(c: Context, value: String) = p(c).edit().putString("selectedTag", value).apply()
    fun ownerTagUnlocked(c: Context) = p(c).getBoolean("ownerTagUnlocked", false)
    fun unlockOwnerTag(c: Context) = p(c).edit().putBoolean("ownerTagUnlocked", true).apply()
    fun lvl(c: Context, k: String) = p(c).getInt("lvl_$k", 0)
    fun setLvl(c: Context, k: String, v: Int) = p(c).edit().putInt("lvl_$k", v).apply()
    fun music(c: Context) = p(c).getBoolean("music", true)
    fun sfx(c: Context) = p(c).getBoolean("sfx", true)
    fun setMusic(c: Context, v: Boolean) = p(c).edit().putBoolean("music", v).apply()
    fun setSfx(c: Context, v: Boolean) = p(c).edit().putBoolean("sfx", v).apply()
    fun skin(c: Context) = p(c).getInt("skin", 0)
    fun setSkin(c: Context, v: Int) = p(c).edit().putInt("skin", v).apply()
    fun owned(c: Context, i: Int) = i == 0 || p(c).getBoolean("skin_$i", false)
    fun setOwned(c: Context, i: Int) = p(c).edit().putBoolean("skin_$i", true).apply()
    fun best(c: Context) = p(c).getInt("best", 0)
    fun unlockedStage(c: Context) = p(c).getInt("unlockedStage", 1).coerceIn(1, 3)
    fun unlockStage(c: Context, stage: Int) { if (stage > unlockedStage(c)) p(c).edit().putInt("unlockedStage", stage.coerceIn(1, 3)).apply() }
    fun setBest(c: Context, v: Int) = p(c).edit().putInt("best", v).apply()
    fun maxBossDefeated(c: Context) = p(c).getInt("bossMax", 0)
    fun recordBossDefeated(c: Context, level: Int) {
        if (level > maxBossDefeated(c)) p(c).edit().putInt("bossMax", level).apply()
    }
    fun weapon(c: Context) = p(c).getInt("weapon", 0)
    fun setWeapon(c: Context, v: Int) = p(c).edit().putInt("weapon", v).apply()
    fun wOwned(c: Context, i: Int) = i == 0 || p(c).getBoolean("w_$i", false)
    fun setWOwned(c: Context, i: Int) = p(c).edit().putBoolean("w_$i", true).apply()
    const val NEED_MS = 600000L
    fun playMs(c: Context) = p(c).getLong("playMs", 0L)
    fun addPlayMs(c: Context, n: Long) = p(c).edit().putLong("playMs", (playMs(c) + n).coerceAtMost(NEED_MS)).apply()
    fun resetPlayMs(c: Context) = p(c).edit().putLong("playMs", 0L).apply()
    fun pending(c: Context) = p(c).getInt("pending", -1)
    fun setPending(c: Context, v: Int) = p(c).edit().putInt("pending", v).apply()
    fun bonusLives(c: Context) = p(c).getInt("bonusLives", 0)
    fun setBonusLives(c: Context, v: Int) = p(c).edit().putInt("bonusLives", v).apply()
    fun dbl(c: Context) = p(c).getBoolean("dbl", false)
    fun setDbl(c: Context, v: Boolean) = p(c).edit().putBoolean("dbl", v).apply()
    fun bonusGames(c: Context) = p(c).getInt("bonusGames", 0)
    fun setBonusGames(c: Context, v: Int) = p(c).edit().putInt("bonusGames", v).apply()
    fun dblGames(c: Context) = p(c).getInt("dblGames", 0)
    fun setDblGames(c: Context, v: Int) = p(c).edit().putInt("dblGames", v).apply()
    private fun savedPrefs(c: Context) = c.getSharedPreferences("saved_game", Context.MODE_PRIVATE)
    fun savedGame(c: Context) = savedPrefs(c).getString("state", null)
    fun hasSavedGame(c: Context) = !savedGame(c).isNullOrBlank()
    fun setSavedGame(c: Context, state: String) = savedPrefs(c).edit().putString("state", state).commit()
    fun clearSavedGame(c: Context) = savedPrefs(c).edit().remove("state").apply()
    fun reset(c: Context) { p(c).edit().clear().apply(); clearSavedGame(c) }

    private const val BACKUP_FORMAT = "tobi-shooter-save"
    fun exportBackup(c: Context): String {
        val values = JSONObject()
        for ((key, value) in p(c).all) {
            when (value) {
                is Boolean, is Int, is Long, is Float, is String -> values.put(key, value)
            }
        }
        return JSONObject().put("format", BACKUP_FORMAT).put("version", 1).put("data", values).toString(2)
    }

    fun importBackup(c: Context, json: String): Boolean {
        return try {
            val root = JSONObject(json)
            if (root.optString("format") != BACKUP_FORMAT || root.optInt("version", -1) != 1) return false
            val values = root.optJSONObject("data") ?: return false
            val edit = p(c).edit().clear()
            val keys = values.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = values.get(key)
                when {
                    key == "username" || key == "selectedTag" -> {
                        if (value !is String || (key == "username" && value.trim().length > 20)) return false
                        edit.putString(key, value.trim())
                    }
                    key == "ownerTagUnlocked" || key == "music" || key == "sfx" || key == "dbl" || key.matches(Regex("(skin_|w_)[0-9]+")) -> {
                        if (value !is Boolean) return false
                        edit.putBoolean(key, value)
                    }
                    key == "playMs" -> {
                        if (value !is Int && value !is Long) return false
                        val n = (value as Number).toLong()
                        if (n < 0 || n > NEED_MS) return false
                        edit.putLong(key, n)
                    }
                    key.matches(Regex("(coins|maxCoins|skin|best|weapon|pending|bonusLives|bonusGames|dblGames|bossMax|bossWins|unlockedStage|lvl_[A-Za-z0-9_]+)")) -> {
                        if (value !is Int && value !is Long) return false
                        val n = (value as Number).toLong()
                        if (n < (if (key == "pending") -1L else 0L) || n > Int.MAX_VALUE) return false
                        if ((key == "skin" && n > 4) || (key == "weapon" && n > 11) || (key == "unlockedStage" && n > 3)) return false
                        if (key == "pending" && n > 7) return false
                        edit.putInt(key, n.toInt())
                    }
                    else -> return false
                }
            }
            edit.commit()
        } catch (_: Exception) { false }
    }
    fun dataDir(c: Context) = File(c.filesDir, "gamedata")
}

object Audio {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopNow() }

    fun start(c: Context) {
        h.removeCallbacks(stopper)
        if (!Save.music(c)) { stopNow(); return }
        if (mp?.isPlaying == true) return
        val f = File(Save.dataDir(c), "music_menu.wav")
        if (!f.exists()) return
        stopNow()
        mp = MediaPlayer().apply { setDataSource(f.path); isLooping = true; setVolume(0.6f, 0.6f); prepare(); start() }
    }
    fun stopSoon() { h.removeCallbacks(stopper); h.postDelayed(stopper, 400) }
    fun stopNow() { h.removeCallbacks(stopper); mp?.release(); mp = null }
}

object Weapons {
    class W(val name: String, val price: Int, val dmg: Int, val rate: Float, val desc: String)
    val list = listOf(
        W("Pistola", 0, 0, 1.0f, "1 bala, daño base"),
        W("Doble cañón", 150, 0, 0.85f, "2 balas paralelas"),
        W("Ametralladora", 300, 0, 0.45f, "Dispara muy rápido"),
        W("Triple abanico", 600, 1, 0.8f, "3 balas en abanico, +1 daño"),
        W("Láser", 1200, 2, 0.4f, "2 balas rápidas, +2 daño"),
        W("Escopeta", 850, 1, 1.45f, "5 perdigones abiertos, +1 daño"),
        W("Cañón de plasma", 2200, 4, 0.72f, "Rayo potente y veloz, +4 daño"),
        W("Espada de energía", 2600, 4, 1.25f, "Tajo de energía ancho, +4 daño"),
        W("Katanas relámpago", 4200, 2, 0.72f, "Dos tajos rápidos y diagonales, +2 daño"),
        W("Sable de fuego", 5200, 3, 0.92f, "Tres llamas en abanico, +3 daño"),
        W("Espada lunar", 6800, 5, 1.15f, "Cinco fragmentos de hielo, +5 daño"),
        W("Hoja sombría", 9000, 7, 0.88f, "Dos tajos oscuros veloces, +7 daño")
    )
}
