package com.tobi.shooter

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.io.File

object Save {
    private fun p(c: Context) = c.getSharedPreferences("save", Context.MODE_PRIVATE)
    fun coins(c: Context) = p(c).getInt("coins", 0)
    fun addCoins(c: Context, n: Int) = p(c).edit().putInt("coins", coins(c) + n).apply()
    fun lvl(c: Context, k: String) = p(c).getInt("lvl_$k", 0)
    fun setLvl(c: Context, k: String, v: Int) = p(c).edit().putInt("lvl_$k", v).apply()
    fun music(c: Context) = p(c).getBoolean("music", true)
    fun sfx(c: Context) = p(c).getBoolean("sfx", true)
    fun setMusic(c: Context, v: Boolean) = p(c).edit().putBoolean("music", v).apply()
    fun setSfx(c: Context, v: Boolean) = p(c).edit().putBoolean("sfx", v).apply()
    fun skin(c: Context) = p(c).getInt("skin", 0)
    fun setSkin(c: Context, v: Int) = p(c).edit().putInt("skin", v).apply()
    fun owned(c: Context, i: Int) = i == 0 || p(c).getBoolean("skin_$i", false)
    fun setOwned(c: Context, i: Int) = p(c).edit().putBoolean("skin_$i", true).apply()
    fun best(c: Context) = p(c).getInt("best", 0)
    fun setBest(c: Context, v: Int) = p(c).edit().putInt("best", v).apply()
    fun weapon(c: Context) = p(c).getInt("weapon", 0)
    fun setWeapon(c: Context, v: Int) = p(c).edit().putInt("weapon", v).apply()
    fun wOwned(c: Context, i: Int) = i == 0 || p(c).getBoolean("w_$i", false)
    fun setWOwned(c: Context, i: Int) = p(c).edit().putBoolean("w_$i", true).apply()
    const val NEED_MS = 600000L
    fun playMs(c: Context) = p(c).getLong("playMs", 0L)
    fun addPlayMs(c: Context, n: Long) = p(c).edit().putLong("playMs", (playMs(c) + n).coerceAtMost(NEED_MS)).apply()
    fun resetPlayMs(c: Context) = p(c).edit().putLong("playMs", 0L).apply()
    fun pending(c: Context) = p(c).getInt("pending", -1)
    fun setPending(c: Context, v: Int) = p(c).edit().putInt("pending", v).apply()
    fun bonusLives(c: Context) = p(c).getInt("bonusLives", 0)
    fun setBonusLives(c: Context, v: Int) = p(c).edit().putInt("bonusLives", v).apply()
    fun dbl(c: Context) = p(c).getBoolean("dbl", false)
    fun setDbl(c: Context, v: Boolean) = p(c).edit().putBoolean("dbl", v).apply()
    fun bonusGames(c: Context) = p(c).getInt("bonusGames", 0)
    fun setBonusGames(c: Context, v: Int) = p(c).edit().putInt("bonusGames", v).apply()
    fun dblGames(c: Context) = p(c).getInt("dblGames", 0)
    fun setDblGames(c: Context, v: Int) = p(c).edit().putInt("dblGames", v).apply()
    fun reset(c: Context) = p(c).edit().clear().apply()
    fun dataDir(c: Context) = File(c.filesDir, "gamedata")
}

object Audio {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private val stopper = Runnable { stopNow() }

    fun start(c: Context) {
        h.removeCallbacks(stopper)
        if (!Save.music(c)) { stopNow(); return }
        if (mp?.isPlaying == true) return
        val f = File(Save.dataDir(c), "music_menu.wav")
        if (!f.exists()) return
        stopNow()
        mp = MediaPlayer().apply { setDataSource(f.path); isLooping = true; setVolume(0.6f, 0.6f); prepare(); start() }
    }
    fun stopSoon() { h.removeCallbacks(stopper); h.postDelayed(stopper, 400) }
    fun stopNow() { h.removeCallbacks(stopper); mp?.release(); mp = null }
}

object Weapons {
    class W(val name: String, val price: Int, val dmg: Int, val rate: Float, val desc: String)
    val list = listOf(
        W("Pistola", 0, 0, 1.0f, "1 bala, daño base"),
        W("Doble cañón", 150, 0, 0.85f, "2 balas paralelas"),
        W("Ametralladora", 300, 0, 0.45f, "Dispara muy rápido"),
        W("Triple abanico", 600, 1, 0.8f, "3 balas en abanico, +1 daño"),
        W("Láser", 1200, 2, 0.4f, "2 balas rápidas, +2 daño")
    )
}
