package com.tobi.shooter

import android.app.Activity
import android.content.Intent
import android.app.AlertDialog
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.ScrollView
import android.widget.Toast
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

class MenuActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var record: TextView
    private lateinit var rb: Button
    private val h = Handler(Looper.getMainLooper())
    private var checkStarted = false
    private var screenActive = false
    private var updateWaiting = false
    private var updateDialog: AlertDialog? = null
    private var lastTimerCheckpoint = 0L
    private fun checkpointTimer() {
        val now = SystemClock.elapsedRealtime()
        if (lastTimerCheckpoint != 0L && now > lastTimerCheckpoint) Save.addPlayMs(this, now - lastTimerCheckpoint)
        lastTimerCheckpoint = now
    }
    private val tick = object : Runnable { override fun run() { checkpointTimer(); updRoulette(); h.postDelayed(this, 1000) } }
    private fun updRoulette() {
        val remainingMs = (Save.NEED_MS - Save.playMs(this@MenuActivity)).coerceAtLeast(0L)
        val left = (remainingMs + 999L) / 1000L
        rb.text = when {
            Save.pending(this) >= 0 -> "RULETA 🎁 ¡Premio para reclamar!"
            left <= 0 -> "RULETA ¡LISTA PARA GIRAR!"
            else -> "RULETA  🔒 %02d:%02d".format(left / 60, left % 60)
        }
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(15, 15, 30))
            setPadding(18, 14, 18, 0)
        }
        info = TextView(this).apply {
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(255, 220, 90))
            gravity = Gravity.CENTER
            setPadding(14, 14, 14, 14)
            background = GradientDrawable().apply {
                setColor(Color.rgb(55, 43, 15))
                cornerRadius = 24f
                setStroke(2, Color.rgb(220, 170, 45))
            }
        }
        screen.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val l = Ui.root(this).apply { setPadding(24, 24, 24, 32); gravity = Gravity.TOP }
        Ui.add(l, Ui.title(this, "SHOOTER", 42f))
        record = Ui.text(this, ""); Ui.add(l, record)
        Ui.add(l, Ui.button(this, "👤  PERFIL", Color.rgb(100, 75, 150)) { showProfile() })
        Ui.add(l, Ui.button(this, "🏷️  ETIQUETAS", Color.rgb(130, 90, 40)) { showTags() })
        Ui.add(l, Ui.button(this, "▶  JUGAR MODO NORMAL", Color.rgb(30, 160, 80)) { startActivity(Intent(this, GameActivity::class.java)) })
        Ui.add(l, Ui.button(this, "🚀  CAMPAÑA • FASE 1", Color.rgb(60, 110, 180)) { startActivity(Intent(this, GameActivity::class.java).putExtra(GameActivity.EXTRA_STAGE, 1)) })
        Ui.add(l, Ui.button(this, "ELEGIR FASE", Color.rgb(60, 110, 180)) { startActivity(Intent(this, StagesActivity::class.java)) })
        Ui.add(l, Ui.button(this, "PARTIDAS GUARDADAS", Color.rgb(35, 115, 170)) { startActivity(Intent(this, SavedGamesActivity::class.java)) })
        Ui.add(l, Ui.button(this, "NUEVO • ENFRENTAR JEFES", Color.rgb(170, 45, 100)) { startActivity(Intent(this, BossesActivity::class.java)) })
        Ui.add(l, Ui.button(this, "MEJORAS") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "upgrades")) })
        Ui.add(l, Ui.button(this, "TIENDA") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "shop")) })
        rb = Ui.button(this, "RULETA", Color.rgb(160, 90, 200)) { startActivity(Intent(this, RouletteActivity::class.java)) }
        Ui.add(l, rb)
        Ui.add(l, Ui.button(this, "OPCIONES", Color.rgb(90, 90, 110)) { startActivity(Intent(this, OptionsActivity::class.java)) })
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(l) }
        screen.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(screen)
    }
    private data class ProfileTag(val id: String, val title: String, val rule: String, val unlocked: () -> Boolean)

    private fun profileTags() = listOf(
        ProfileTag("three_bosses", "Cazajefes", "Derrotá 3 jefes.") { Save.bossWins(this) >= 3 },
        ProfileTag("score_1000", "Puntería", "Alcanzá 1.000 puntos en una partida.") { Save.best(this) >= 1_000 },
        ProfileTag("ten_bosses", "Verdugo", "Derrotá 10 jefes en total.") { Save.bossWins(this) >= 10 },
        ProfileTag("score_5000", "Leyenda", "Alcanzá 5.000 puntos en una partida.") { Save.best(this) >= 5_000 },
        ProfileTag("coin_record", "Magnate", "Juntá 5.000 monedas o más al mismo tiempo.") { Save.maxCoins(this) >= 5_000 },
        ProfileTag("arsenal", "Arsenal", "Desbloqueá 5 armas.") { (0..11).count { Save.wOwned(this, it) } >= 5 },
        ProfileTag("owner", "OWNER", "Requiere aprobación del creador; todavía no disponible.") { false }
    )

    private fun showTags() {
        val tags = profileTags()
        val selected = Save.selectedTag(this)
        val rows = tags.map { tag ->
            val mark = if (tag.unlocked()) "✓" else "🔒"
            val equipped = if (selected == tag.id) " • puesta" else ""
            "$mark  ${tag.title}$equipped"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("ETIQUETAS • Tocá para ver cómo")
            .setItems(rows) { _, which -> showTagDetails(tags[which]) }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showTagDetails(tag: ProfileTag) {
        if (tag.id == "owner" && !tag.unlocked()) {
            AlertDialog.Builder(this)
                .setTitle("Etiqueta OWNER")
                .setMessage("Para conseguir esta etiqueta necesitás la aprobación del creador. Las solicitudes y aprobaciones desde el juego todavía no están disponibles.")
                .setPositiveButton("Entendido", null)
                .show()
            return
        }
        val unlocked = tag.unlocked()
        val message = "${tag.rule}\n\n${if (unlocked) "Desbloqueada." else "Todavía bloqueada."}${if (Save.selectedTag(this) == tag.id) " Ya está puesta en tu nombre." else ""}"
        val dialog = AlertDialog.Builder(this)
            .setTitle("Etiqueta ${tag.title}")
            .setMessage(message)
            .setPositiveButton(if (unlocked) "Poner en mi nombre" else "Entendido", null)
            .setNegativeButton("Cerrar", null)
            .create()
        dialog.setOnShowListener {
            if (unlocked) dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                Save.setSelectedTag(this, tag.id)
                dialog.dismiss()
                Toast.makeText(this, "${tag.title} puesta en tu nombre", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun showProfile() {
        val bossRecord = Save.maxBossDefeated(this)
        val bossText = if (bossRecord == 0) "Todavía no derrotaste jefes" else "Jefe de mayor nivel derrotado: $bossRecord"
        val tag = profileTags().firstOrNull { it.id == Save.selectedTag(this) && it.unlocked() }?.title
        val decoratedName = if (tag.isNullOrBlank()) Save.username(this) else "${Save.username(this)}  【$tag】"
        AlertDialog.Builder(this)
            .setTitle("PERFIL")
            .setMessage("Nombre: $decoratedName\nMáximo de monedas: ${Save.maxCoins(this)}\n$bossText\nJefes derrotados: ${Save.bossWins(this)}")
            .setPositiveButton("Cerrar", null)
            .show()
    }

    override fun onResume() {
        super.onResume(); Audio.start(this); lastTimerCheckpoint = SystemClock.elapsedRealtime(); h.post(tick)
        info.text = "🪙  MONEDAS: ${Save.coins(this)}"
        record.text = "Récord: ${Save.best(this)}"
        screenActive = true
        if (!checkStarted) { checkStarted = true; checkUpdatesOnEntry() }
        showUpdateIfReady()
    }
    private fun checkUpdatesOnEntry() {
        Thread {
            val available = try { UpdateChecker.isUpdateAvailable(applicationContext) } catch (_: Exception) { false }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                updateWaiting = available
                showUpdateIfReady()
            }
        }.start()
    }

    private fun showUpdateIfReady() {
        if (!screenActive || !updateWaiting || isFinishing || isDestroyed || updateDialog?.isShowing == true) return
        updateWaiting = false
        updateDialog = AlertDialog.Builder(this)
            .setTitle("¡Hay una actualización!")
            .setMessage("Está disponible una versión nueva de Shooter. ¿Querés descargarla ahora?")
            .setNegativeButton("Más tarde", null)
            .setPositiveButton("Descargar") { _, _ ->
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/tobybloxarg-tech/shooter-game/releases/download/latest-build/shooter.apk"))) }
                catch (_: Exception) { Toast.makeText(this, "No se pudo abrir la descarga", Toast.LENGTH_LONG).show() }
            }
            .show()
    }

    override fun onPause() { screenActive = false; h.removeCallbacks(tick); checkpointTimer(); lastTimerCheckpoint = 0L; super.onPause(); Audio.stopSoon() }
}
