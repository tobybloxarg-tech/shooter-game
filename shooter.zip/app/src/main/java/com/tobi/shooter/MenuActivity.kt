package com.tobi.shooter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.ScrollView
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

class MenuActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var rb: Button
    private val h = Handler(Looper.getMainLooper())
    private var lastTimerCheckpoint = 0L
    private fun checkpointTimer() {
        val now = SystemClock.elapsedRealtime()
        if (lastTimerCheckpoint != 0L && now > lastTimerCheckpoint) Save.addPlayMs(this, now - lastTimerCheckpoint)
        lastTimerCheckpoint = now
    }
    private val tick = object : Runnable { override fun run() { checkpointTimer(); updRoulette(); h.postDelayed(this, 1000) } }
    private fun updRoulette() {
        val remainingMs = (Save.NEED_MS - Save.playMs(this@MenuActivity)).coerceAtLeast(0L)
        val left = (remainingMs + 999L) / 1000L
        rb.text = when {
            Save.pending(this) >= 0 -> "RULETA 🎁 ¡Premio para reclamar!"
            left <= 0 -> "RULETA ¡LISTA PARA GIRAR!"
            else -> "RULETA  🔒 %02d:%02d".format(left / 60, left % 60)
        }
    }
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val l = Ui.root(this)
        Ui.add(l, Ui.title(this, "SHOOTER", 42f))
        info = Ui.text(this, ""); Ui.add(l, info)
        Ui.add(l, Ui.button(this, "▶  PLAY", Color.rgb(30, 160, 80)) { startActivity(Intent(this, GameActivity::class.java)) })
        Ui.add(l, Ui.button(this, "NUEVO • ENFRENTAR JEFES", Color.rgb(170, 45, 100)) { startActivity(Intent(this, BossesActivity::class.java)) })
        Ui.add(l, Ui.button(this, "MEJORAS") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "upgrades")) })
        Ui.add(l, Ui.button(this, "TIENDA") { startActivity(Intent(this, StoreActivity::class.java).putExtra("mode", "shop")) })
        rb = Ui.button(this, "RULETA", Color.rgb(160, 90, 200)) { startActivity(Intent(this, RouletteActivity::class.java)) }
        Ui.add(l, rb)
        Ui.add(l, Ui.button(this, "OPCIONES", Color.rgb(90, 90, 110)) { startActivity(Intent(this, OptionsActivity::class.java)) })
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(l) })
    }
    override fun onResume() {
        super.onResume(); Audio.start(this); lastTimerCheckpoint = SystemClock.elapsedRealtime(); h.post(tick)
        info.text = "Monedas: ${Save.coins(this)}   |   Récord: ${Save.best(this)}"
    }
    override fun onPause() { h.removeCallbacks(tick); checkpointTimer(); lastTimerCheckpoint = 0L; super.onPause(); Audio.stopSoon() }
}
