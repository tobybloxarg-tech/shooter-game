plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.tobi.shooter"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tobi.shooter"
        minSdk = 24; targetSdk = 35
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt(); versionName = "1.0"
    }
    val ks = System.getenv("KEYSTORE_PATH")
    if (ks != null) {
        signingConfigs.create("upload") {
            storeFile = file(ks); storeType = "pkcs12"
            storePassword = System.getenv("KEYSTORE_PASSWORD"); keyAlias = "upload"; keyPassword = System.getenv("KEYSTORE_PASSWORD")
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (ks != null) signingConfig = signingConfigs.getByName("upload")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
